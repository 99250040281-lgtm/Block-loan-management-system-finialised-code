const request = require("supertest");
const app = require("../src/app");

describe("Backend API Integration Test Suite", () => {
  it("GET /health should return 200 and healthy status", async () => {
    const res = await request(app).get("/health");
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe("healthy");
    expect(res.body.service).toContain("Blockchain Loan Management System API");
  });

  it("POST /api/auth/login with missing email should return 400", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ password: "password123" });
    expect(res.statusCode).toBe(400);
    expect(res.body.success).toBe(false);
  });

  it("POST /api/auth/login with institutional admin should issue JWT token", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: "kurubamahesh.cse@gmail.com", password: "AdminPassword123!" });
    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.token).toBeDefined();
    expect(res.body.user.role).toBe("admin");
  });

  it("GET /api/applications without auth token should return 401", async () => {
    const res = await request(app).get("/api/applications");
    expect(res.statusCode).toBe(401);
  });
});
