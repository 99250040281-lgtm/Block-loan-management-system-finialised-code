const express = require("express");
const router = express.Router();
const documentController = require("../controllers/documentController");
const { authenticate, requireRole } = require("../middleware/auth");

router.get("/", authenticate, documentController.getDocuments);
router.post("/upload", authenticate, documentController.uploadDocument);
router.patch("/:id/verify", authenticate, requireRole("admin", "super_admin"), documentController.verifyDocument);

module.exports = router;
