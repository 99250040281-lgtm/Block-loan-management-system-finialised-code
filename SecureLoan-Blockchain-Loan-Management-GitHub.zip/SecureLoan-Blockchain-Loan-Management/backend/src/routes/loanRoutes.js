const express = require("express");
const router = express.Router();
const loanController = require("../controllers/loanController");
const { authenticate } = require("../middleware/auth");

router.get("/", authenticate, loanController.getLoans);
router.get("/:id", authenticate, loanController.getLoanById);

module.exports = router;
