const express = require("express");
const router = express.Router();
const repaymentController = require("../controllers/repaymentController");
const { authenticate } = require("../middleware/auth");

router.get("/", authenticate, repaymentController.getRepayments);
router.post("/", authenticate, repaymentController.makeRepayment);

module.exports = router;
