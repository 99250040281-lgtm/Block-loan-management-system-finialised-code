const express = require("express");
const router = express.Router();
const applicationController = require("../controllers/applicationController");
const { authenticate, requireRole } = require("../middleware/auth");

router.get("/", authenticate, applicationController.getApplications);
router.get("/:id", authenticate, applicationController.getApplicationById);
router.post("/", authenticate, requireRole("borrower"), applicationController.createApplication);
router.post("/:id/approve", authenticate, requireRole("admin", "super_admin"), applicationController.approveApplication);
router.post("/:id/reject", authenticate, requireRole("admin", "super_admin"), applicationController.rejectApplication);

module.exports = router;
