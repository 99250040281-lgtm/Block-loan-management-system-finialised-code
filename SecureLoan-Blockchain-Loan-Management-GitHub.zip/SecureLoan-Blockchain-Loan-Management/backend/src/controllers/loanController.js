const Loan = require("../models/Loan");

exports.getLoans = async (req, res, next) => {
  try {
    const filter = {};
    if (req.user.role === "borrower") {
      filter.borrower_id = req.user.id;
    }

    const loans = await Loan.findAll(filter);
    res.json({ success: true, count: loans.length, data: loans });
  } catch (error) {
    next(error);
  }
};

exports.getLoanById = async (req, res, next) => {
  try {
    const loan = await Loan.findById(req.params.id);
    if (!loan) {
      return res.status(404).json({ success: false, message: "Loan record not found." });
    }

    if (req.user.role === "borrower" && loan.borrower_id !== req.user.id) {
      return res.status(403).json({ success: false, message: "Unauthorized access to loan record." });
    }

    res.json({ success: true, data: loan });
  } catch (error) {
    next(error);
  }
};
