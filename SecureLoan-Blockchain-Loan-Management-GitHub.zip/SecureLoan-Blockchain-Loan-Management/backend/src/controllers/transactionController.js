const Transaction = require("../models/Transaction");

exports.getTransactions = async (req, res, next) => {
  try {
    const filter = {};
    if (req.user.role === "borrower") {
      filter.borrower_id = req.user.id;
    }

    const transactions = await Transaction.findAll(filter);
    res.json({ success: true, count: transactions.length, data: transactions });
  } catch (error) {
    next(error);
  }
};
