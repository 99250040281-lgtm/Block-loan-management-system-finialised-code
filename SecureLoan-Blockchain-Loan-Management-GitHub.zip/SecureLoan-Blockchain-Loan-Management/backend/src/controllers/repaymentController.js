const Loan = require("../models/Loan");
const Repayment = require("../models/Repayment");
const Transaction = require("../models/Transaction");

exports.getRepayments = async (req, res, next) => {
  try {
    const filter = {};
    if (req.user.role === "borrower") {
      filter.borrower_id = req.user.id;
    }
    if (req.query.loan_id) {
      filter.loan_id = req.query.loan_id;
    }

    const repayments = await Repayment.findAll(filter);
    res.json({ success: true, count: repayments.length, data: repayments });
  } catch (error) {
    next(error);
  }
};

exports.makeRepayment = async (req, res, next) => {
  try {
    const { loan_id, amount, payment_method, on_chain_tx_hash, notes } = req.body;
    if (!loan_id || !amount || Number(amount) <= 0) {
      return res.status(400).json({ success: false, message: "Valid loan_id and amount are required." });
    }

    const loan = await Loan.findById(loan_id);
    if (!loan) {
      return res.status(404).json({ success: false, message: "Loan not found." });
    }

    if (req.user.role === "borrower" && loan.borrower_id !== req.user.id) {
      return res.status(403).json({ success: false, message: "Unauthorized repayment." });
    }

    const payAmount = Math.min(Number(amount), Number(loan.remaining_balance));
    const rate = Number(loan.interest_rate) / 100;
    const interestPortion = payAmount * (rate / (1 + rate));
    const principalPortion = payAmount - interestPortion;

    const repayment = await Repayment.create({
      loan_id,
      borrower_id: loan.borrower_id,
      amount: payAmount,
      principal_paid: principalPortion,
      interest_paid: interestPortion,
      payment_method: payment_method || "CRYPTO_ETH",
      on_chain_tx_hash,
      notes,
    });

    const newRemaining = Math.max(0, Number(loan.remaining_balance) - payAmount);
    const newStatus = newRemaining === 0 ? "COMPLETED" : "ACTIVE";
    const updatedLoan = await Loan.updateBalance(loan_id, newRemaining, newStatus);

    await Transaction.create({
      loan_id: loan.id,
      application_id: loan.application_id,
      borrower_id: loan.borrower_id,
      borrower_name: loan.borrower_name,
      type: "REPAYMENT",
      amount: payAmount,
      tx_hash: on_chain_tx_hash || null,
      network: on_chain_tx_hash ? "Ethereum Sepolia Testnet" : "Secure Loan Payment Clearing",
    });

    res.status(201).json({ success: true, repayment, loan: updatedLoan });
  } catch (error) {
    next(error);
  }
};
