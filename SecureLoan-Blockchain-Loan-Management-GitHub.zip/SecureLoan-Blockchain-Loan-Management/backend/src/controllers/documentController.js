const Document = require("../models/Document");

exports.getDocuments = async (req, res, next) => {
  try {
    const filter = {};
    if (req.user.role === "borrower") {
      filter.borrower_id = req.user.id;
    }
    if (req.query.application_id) {
      filter.application_id = req.query.application_id;
    }

    const documents = await Document.findAll(filter);
    res.json({ success: true, count: documents.length, data: documents });
  } catch (error) {
    next(error);
  }
};

exports.uploadDocument = async (req, res, next) => {
  try {
    const { application_id, document_type, file_name, file_size, mime_type, file_url, ipfs_hash } = req.body;
    if (!application_id || !document_type || !file_name) {
      return res.status(400).json({ success: false, message: "Missing required document attributes." });
    }

    const doc = await Document.create({
      application_id,
      borrower_id: req.user.id,
      document_type,
      file_name,
      file_size: file_size || 0,
      mime_type: mime_type || "application/pdf",
      file_url: file_url || "",
      ipfs_hash: ipfs_hash || null,
    });

    res.status(201).json({ success: true, data: doc });
  } catch (error) {
    next(error);
  }
};

exports.verifyDocument = async (req, res, next) => {
  try {
    const { status, remarks } = req.body;
    if (!["VERIFIED", "REJECTED"].includes(status)) {
      return res.status(400).json({ success: false, message: "Invalid verification status." });
    }

    const doc = await Document.verify(req.params.id, status, req.user.id, remarks);
    res.json({ success: true, data: doc });
  } catch (error) {
    next(error);
  }
};
