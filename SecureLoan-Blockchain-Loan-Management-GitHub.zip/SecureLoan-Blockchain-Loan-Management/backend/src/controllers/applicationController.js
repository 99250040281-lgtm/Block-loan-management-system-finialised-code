const Application = require("../models/Application");
const Loan = require("../models/Loan");
const Transaction = require("../models/Transaction");
const blockchainService = require("../services/blockchainService");

exports.getApplications = async (req, res, next) => {
  try {
    const filter = {};
    if (req.user.role === "borrower") {
      filter.borrower_id = req.user.id;
    } else if (req.user.role === "admin") {
      filter.admin_id = req.user.id;
    }

    const applications = await Application.findAll(filter);
    res.json({ success: true, count: applications.length, data: applications });
  } catch (error) {
    next(error);
  }
};

exports.getApplicationById = async (req, res, next) => {
  try {
    const application = await Application.findById(req.params.id);
    if (!application) {
      return res.status(404).json({ success: false, message: "Application not found." });
    }

    if (req.user.role === "borrower" && application.borrower_id !== req.user.id) {
      return res.status(403).json({ success: false, message: "Unauthorized access to application." });
    }

    res.json({ success: true, data: application });
  } catch (error) {
    next(error);
  }
};

exports.createApplication = async (req, res, next) => {
  try {
    if (req.user.role !== "borrower") {
      return res.status(403).json({ success: false, message: "Only borrowers can apply for loans." });
    }

    const { amount, purpose, term_months, annual_income, employment_type, employer_name } = req.body;
    if (!amount || !purpose || !term_months || !annual_income || !employment_type) {
      return res.status(400).json({ success: false, message: "Missing required loan application fields." });
    }

    const app = await Application.create({
      borrower_id: req.user.id,
      amount,
      purpose,
      term_months,
      annual_income,
      employment_type,
      employer_name,
    });

    res.status(201).json({ success: true, data: app });
  } catch (error) {
    next(error);
  }
};

exports.approveApplication = async (req, res, next) => {
  try {
    const { remarks, conditions, approved_amount, blockchain_loan_id, on_chain_tx_hash } = req.body;
    const app = await Application.findById(req.params.id);
    if (!app) {
      return res.status(404).json({ success: false, message: "Application not found." });
    }

    const principal = Number(approved_amount || app.amount);
    const rate = Number(app.interest_rate_bps) / 10000;
    const totalInterest = (principal * rate * app.term_months) / 12;
    const totalRepayable = principal + totalInterest;
    const monthlyInstallment = totalRepayable / app.term_months;

    const updatedApp = await Application.updateStatus(req.params.id, {
      status: "APPROVED",
      remarks,
      conditions,
      admin_id: req.user.id,
      blockchain_loan_id,
      on_chain_tx_hash,
    });

    const newLoan = await Loan.create({
      application_id: app.id,
      borrower_id: app.borrower_id,
      principal_amount: principal,
      interest_rate: rate * 100,
      total_repayable: totalRepayable,
      remaining_balance: totalRepayable,
      monthly_installment: monthlyInstallment,
      term_months: app.term_months,
      blockchain_loan_id,
      on_chain_tx_hash,
    });

    await Transaction.create({
      loan_id: newLoan.id,
      application_id: app.id,
      borrower_id: app.borrower_id,
      borrower_name: app.borrower_name,
      type: "DISBURSEMENT",
      amount: principal,
      tx_hash: on_chain_tx_hash || null,
      network: on_chain_tx_hash ? "Ethereum Sepolia Testnet" : "Internal Escrow Disbursement",
    });

    res.json({ success: true, application: updatedApp, loan: newLoan });
  } catch (error) {
    next(error);
  }
};

exports.rejectApplication = async (req, res, next) => {
  try {
    const { remarks, on_chain_tx_hash } = req.body;
    const updatedApp = await Application.updateStatus(req.params.id, {
      status: "REJECTED",
      remarks,
      admin_id: req.user.id,
      on_chain_tx_hash,
    });

    res.json({ success: true, application: updatedApp });
  } catch (error) {
    next(error);
  }
};
