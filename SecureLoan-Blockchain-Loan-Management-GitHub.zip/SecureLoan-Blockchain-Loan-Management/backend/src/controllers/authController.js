const jwt = require("jsonwebtoken");
const config = require("../config/environment");
const User = require("../models/User");

exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, message: "Email is required." });
    }

    const normalizedEmail = email.trim().toLowerCase();

    // Check if institutional admin
    if (normalizedEmail === config.ADMIN_EMAIL.toLowerCase()) {
      const adminUser = {
        id: "usr_admin_mahesh",
        email: normalizedEmail,
        full_name: "Mahesh",
        role: "admin",
      };
      const token = jwt.sign(adminUser, config.JWT_SECRET, { expiresIn: config.JWT_EXPIRES_IN });
      return res.json({ success: true, token, user: adminUser });
    }

    let user = await User.findByEmail(normalizedEmail);
    if (!user) {
      return res.status(404).json({ success: false, message: "User account not found. Please register." });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, full_name: user.full_name },
      config.JWT_SECRET,
      { expiresIn: config.JWT_EXPIRES_IN }
    );

    res.json({ success: true, token, user });
  } catch (error) {
    next(error);
  }
};

exports.register = async (req, res, next) => {
  try {
    const { email, full_name, phone, wallet_address } = req.body;
    if (!email || !full_name) {
      return res.status(400).json({ success: false, message: "Email and full name are required." });
    }

    const normalizedEmail = email.trim().toLowerCase();
    if (normalizedEmail === config.ADMIN_EMAIL.toLowerCase()) {
      return res.status(400).json({ success: false, message: "This email is reserved for administration." });
    }

    const existing = await User.findByEmail(normalizedEmail);
    if (existing) {
      return res.status(409).json({ success: false, message: "Email is already registered." });
    }

    const id = `usr_${Date.now()}`;
    const newUser = await User.create({
      id,
      email: normalizedEmail,
      full_name,
      role: "borrower",
      phone: phone || "",
      wallet_address: wallet_address || "",
    });

    const token = jwt.sign(
      { id: newUser.id, email: newUser.email, role: newUser.role, full_name: newUser.full_name },
      config.JWT_SECRET,
      { expiresIn: config.JWT_EXPIRES_IN }
    );

    res.status(201).json({ success: true, token, user: newUser });
  } catch (error) {
    next(error);
  }
};

exports.getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    res.json({ success: true, user: user || req.user });
  } catch (error) {
    next(error);
  }
};
