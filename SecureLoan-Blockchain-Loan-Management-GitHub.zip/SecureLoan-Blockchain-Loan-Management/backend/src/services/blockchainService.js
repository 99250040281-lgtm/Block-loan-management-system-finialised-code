const { ethers } = require("ethers");
const config = require("../config/environment");
const LoanManagementABI = require("../../../blockchain/contracts/LoanManagement.json");

class BackendBlockchainService {
  constructor() {
    this.provider = new ethers.JsonRpcProvider(config.BLOCKCHAIN_RPC_URL);
    this.contractAddress = config.CONTRACT_ADDRESS;
  }

  getContract() {
    if (!this.contractAddress) {
      throw new Error("Contract address is not configured.");
    }
    return new ethers.Contract(this.contractAddress, LoanManagementABI.abi, this.provider);
  }

  async getOnChainLoan(loanId) {
    try {
      const contract = this.getContract();
      const data = await contract.getLoan(loanId);
      return {
        id: Number(data[0]),
        borrower: data[1],
        principalAmount: ethers.formatEther(data[2]),
        termMonths: Number(data[3]),
        interestRateBps: Number(data[4]),
        totalRepayable: ethers.formatEther(data[5]),
        amountRepaid: ethers.formatEther(data[6]),
        status: Number(data[7]),
        documentIpfsHash: data[8],
        adminRemarks: data[9],
        createdAt: new Date(Number(data[10]) * 1000).toISOString(),
      };
    } catch (error) {
      console.warn(`Could not fetch on-chain loan #${loanId}:`, error.message);
      return null;
    }
  }

  async getLoanCounter() {
    try {
      const contract = this.getContract();
      const counter = await contract.loanCounter();
      return Number(counter);
    } catch (error) {
      console.warn("Could not fetch loan counter:", error.message);
      return 0;
    }
  }
}

module.exports = new BackendBlockchainService();
