const db = require("../config/database");

class User {
  static async findById(id) {
    const res = await db.query("SELECT * FROM profiles WHERE id = $1", [id]);
    return res.rows[0] || null;
  }

  static async findByEmail(email) {
    const res = await db.query("SELECT * FROM profiles WHERE LOWER(email) = LOWER($1)", [email]);
    return res.rows[0] || null;
  }

  static async create({ id, email, full_name, role = "borrower", phone = "", wallet_address = "", organization = "" }) {
    const query = `
      INSERT INTO profiles (id, email, full_name, role, phone, wallet_address, organization, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), NOW())
      RETURNING *;
    `;
    const res = await db.query(query, [id, email, full_name, role, phone, wallet_address, organization]);
    return res.rows[0];
  }

  static async updateWallet(id, wallet_address) {
    const res = await db.query(
      "UPDATE profiles SET wallet_address = $1, updated_at = NOW() WHERE id = $2 RETURNING *",
      [wallet_address, id]
    );
    return res.rows[0];
  }
}

module.exports = User;
