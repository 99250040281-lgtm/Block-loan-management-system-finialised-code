const db = require("../config/database");

class Application {
  static async findById(id) {
    const res = await db.query(
      `SELECT a.*, p.full_name as borrower_name, p.email as borrower_email
       FROM applications a
       JOIN profiles p ON a.borrower_id = p.id
       WHERE a.id = $1`,
      [id]
    );
    return res.rows[0] || null;
  }

  static async findAll(filter = {}) {
    let query = `
      SELECT a.*, p.full_name as borrower_name, p.email as borrower_email
      FROM applications a
      JOIN profiles p ON a.borrower_id = p.id
    `;
    const params = [];

    if (filter.borrower_id) {
      params.push(filter.borrower_id);
      query += ` WHERE a.borrower_id = $${params.length}`;
    } else if (filter.admin_id) {
      params.push(filter.admin_id);
      query += ` WHERE (a.admin_id = $${params.length} OR a.admin_id IS NULL)`;
    }

    query += " ORDER BY a.created_at DESC";
    const res = await db.query(query, params);
    return res.rows;
  }

  static async create(data) {
    const id = `app_${Date.now()}`;
    const countRes = await db.query("SELECT COUNT(*) FROM applications");
    const appNum = `APP-${new Date().getFullYear()}-${String(Number(countRes.rows[0].count) + 1).padStart(3, "0")}`;

    const query = `
      INSERT INTO applications (
        id, application_number, borrower_id, amount, purpose, term_months,
        annual_income, employment_type, employer_name, credit_score, status,
        interest_rate_bps, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'PENDING', 850, NOW(), NOW())
      RETURNING *;
    `;
    const res = await db.query(query, [
      id,
      appNum,
      data.borrower_id,
      data.amount,
      data.purpose,
      data.term_months,
      data.annual_income,
      data.employment_type,
      data.employer_name || "",
      data.credit_score || 720,
    ]);
    return res.rows[0];
  }

  static async updateStatus(id, { status, remarks = "", conditions = "", admin_id, blockchain_loan_id, on_chain_tx_hash }) {
    const query = `
      UPDATE applications
      SET status = $1, remarks = $2, conditions = $3, admin_id = COALESCE($4, admin_id),
          blockchain_loan_id = COALESCE($5, blockchain_loan_id),
          on_chain_tx_hash = COALESCE($6, on_chain_tx_hash),
          updated_at = NOW()
      WHERE id = $7
      RETURNING *;
    `;
    const res = await db.query(query, [status, remarks, conditions, admin_id, blockchain_loan_id, on_chain_tx_hash, id]);
    return res.rows[0];
  }
}

module.exports = Application;
