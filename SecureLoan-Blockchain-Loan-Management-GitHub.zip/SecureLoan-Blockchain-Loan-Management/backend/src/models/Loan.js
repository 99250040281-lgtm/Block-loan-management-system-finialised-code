const db = require("../config/database");

class Loan {
  static async findById(id) {
    const res = await db.query(
      `SELECT l.*, p.full_name as borrower_name, p.email as borrower_email
       FROM loans l
       JOIN profiles p ON l.borrower_id = p.id
       WHERE l.id = $1`,
      [id]
    );
    return res.rows[0] || null;
  }

  static async findAll(filter = {}) {
    let query = `
      SELECT l.*, p.full_name as borrower_name, p.email as borrower_email
      FROM loans l
      JOIN profiles p ON l.borrower_id = p.id
    `;
    const params = [];

    if (filter.borrower_id) {
      params.push(filter.borrower_id);
      query += ` WHERE l.borrower_id = $${params.length}`;
    }

    query += " ORDER BY l.created_at DESC";
    const res = await db.query(query, params);
    return res.rows;
  }

  static async create(data) {
    const id = `loan_${Date.now()}`;
    const countRes = await db.query("SELECT COUNT(*) FROM loans");
    const loanNum = `LN-${new Date().getFullYear()}-${String(Number(countRes.rows[0].count) + 1).padStart(3, "0")}`;

    const query = `
      INSERT INTO loans (
        id, loan_number, application_id, borrower_id, principal_amount,
        interest_rate, total_repayable, remaining_balance, monthly_installment,
        term_months, start_date, due_date, status, blockchain_loan_id, on_chain_tx_hash,
        created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, CURRENT_DATE, CURRENT_DATE + ($10 || ' months')::INTERVAL, 'ACTIVE', $11, $12, NOW(), NOW())
      RETURNING *;
    `;
    const res = await db.query(query, [
      id,
      loanNum,
      data.application_id,
      data.borrower_id,
      data.principal_amount,
      data.interest_rate,
      data.total_repayable,
      data.remaining_balance,
      data.monthly_installment,
      data.term_months,
      data.blockchain_loan_id || null,
      data.on_chain_tx_hash || null,
    ]);
    return res.rows[0];
  }

  static async updateBalance(id, remaining_balance, status = "ACTIVE") {
    const query = `
      UPDATE loans
      SET remaining_balance = $1, status = $2, updated_at = NOW()
      WHERE id = $3
      RETURNING *;
    `;
    const res = await db.query(query, [remaining_balance, status, id]);
    return res.rows[0];
  }
}

module.exports = Loan;
