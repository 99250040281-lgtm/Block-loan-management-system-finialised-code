const db = require("../config/database");

class Repayment {
  static async findAll(filter = {}) {
    let query = "SELECT * FROM repayments";
    const params = [];

    if (filter.borrower_id) {
      params.push(filter.borrower_id);
      query += ` WHERE borrower_id = $${params.length}`;
    }

    if (filter.loan_id) {
      if (params.length === 0) {
        params.push(filter.loan_id);
        query += ` WHERE loan_id = $${params.length}`;
      } else {
        params.push(filter.loan_id);
        query += ` AND loan_id = $${params.length}`;
      }
    }

    query += " ORDER BY payment_date DESC";
    const res = await db.query(query, params);
    return res.rows;
  }

  static async create(data) {
    const id = `rep_${Date.now()}`;
    const countRes = await db.query("SELECT COUNT(*) FROM repayments WHERE loan_id = $1", [data.loan_id]);
    const installmentNumber = Number(countRes.rows[0].count) + 1;

    const query = `
      INSERT INTO repayments (
        id, loan_id, borrower_id, installment_number, amount,
        principal_paid, interest_paid, payment_method, status, payment_date,
        on_chain_tx_hash, receipt_url, notes, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'PAID', NOW(), $9, $10, $11, NOW())
      RETURNING *;
    `;
    const res = await db.query(query, [
      id,
      data.loan_id,
      data.borrower_id,
      installmentNumber,
      data.amount,
      data.principal_paid,
      data.interest_paid,
      data.payment_method || "CRYPTO_ETH",
      data.on_chain_tx_hash || null,
      `/receipts/REC-${Date.now().toString().slice(-6)}.pdf`,
      data.notes || `Installment #${installmentNumber} settled`,
    ]);
    return res.rows[0];
  }
}

module.exports = Repayment;
