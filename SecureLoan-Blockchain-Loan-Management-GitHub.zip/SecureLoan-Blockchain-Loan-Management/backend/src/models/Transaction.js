const db = require("../config/database");

class Transaction {
  static async findAll(filter = {}) {
    let query = "SELECT * FROM transactions";
    const params = [];

    if (filter.borrower_id) {
      params.push(filter.borrower_id);
      query += ` WHERE borrower_id = $${params.length}`;
    }

    query += " ORDER BY created_at DESC";
    const res = await db.query(query, params);
    return res.rows;
  }

  static async create(data) {
    const id = `tx_${Date.now()}`;
    const query = `
      INSERT INTO transactions (
        id, loan_id, application_id, borrower_id, borrower_name,
        type, amount, status, tx_hash, network, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, 'COMPLETED', $8, $9, NOW())
      RETURNING *;
    `;
    const res = await db.query(query, [
      id,
      data.loan_id || null,
      data.application_id || null,
      data.borrower_id,
      data.borrower_name,
      data.type,
      data.amount,
      data.tx_hash || null,
      data.network || "Ethereum Sepolia Testnet",
    ]);
    return res.rows[0];
  }
}

module.exports = Transaction;
