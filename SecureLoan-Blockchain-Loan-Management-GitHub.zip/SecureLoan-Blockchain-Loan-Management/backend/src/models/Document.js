const db = require("../config/database");

class Document {
  static async findAll(filter = {}) {
    let query = "SELECT * FROM documents";
    const params = [];

    if (filter.borrower_id) {
      params.push(filter.borrower_id);
      query += ` WHERE borrower_id = $${params.length}`;
    }

    if (filter.application_id) {
      if (params.length === 0) {
        params.push(filter.application_id);
        query += ` WHERE application_id = $${params.length}`;
      } else {
        params.push(filter.application_id);
        query += ` AND application_id = $${params.length}`;
      }
    }

    query += " ORDER BY created_at DESC";
    const res = await db.query(query, params);
    return res.rows;
  }

  static async create(data) {
    const id = `doc_${Date.now()}`;
    const query = `
      INSERT INTO documents (
        id, application_id, borrower_id, document_type, file_name,
        file_size, mime_type, file_url, ipfs_hash, verification_status, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'PENDING', NOW())
      RETURNING *;
    `;
    const res = await db.query(query, [
      id,
      data.application_id,
      data.borrower_id,
      data.document_type,
      data.file_name,
      data.file_size,
      data.mime_type,
      data.file_url,
      data.ipfs_hash || null,
    ]);
    return res.rows[0];
  }

  static async verify(id, status, verified_by, remarks = "") {
    const query = `
      UPDATE documents
      SET verification_status = $1, verified_by = $2, remarks = $3, verified_at = NOW()
      WHERE id = $4
      RETURNING *;
    `;
    const res = await db.query(query, [status, verified_by, remarks, id]);
    return res.rows[0];
  }
}

module.exports = Document;
