const app = require("./app");
const config = require("./config/environment");

const PORT = config.PORT;

const server = app.listen(PORT, () => {
  console.log("==================================================");
  console.log(`🚀 Loan Management Backend API running on port ${PORT}`);
  console.log(`🌐 Environment: ${config.NODE_ENV}`);
  console.log(`⛓️  Blockchain RPC: ${config.BLOCKCHAIN_RPC_URL}`);
  console.log(`📜 Contract Address: ${config.CONTRACT_ADDRESS}`);
  console.log("==================================================");
});

module.exports = server;
