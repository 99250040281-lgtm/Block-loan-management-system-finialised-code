const dotenv = require("dotenv");
const path = require("path");

dotenv.config({ path: path.join(__dirname, "../../../configuration/.env") });

module.exports = {
  NODE_ENV: process.env.NODE_ENV || "development",
  PORT: process.env.PORT || 5000,
  DATABASE_URL: process.env.DATABASE_URL || "postgresql://postgres:postgres@localhost:5432/secure_loan_db",
  JWT_SECRET: process.env.JWT_SECRET || "secure-loan-management-system-super-secret-key-2026",
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || "7d",
  BLOCKCHAIN_RPC_URL: process.env.SEPOLIA_RPC_URL || "https://rpc.sepolia.org",
  CONTRACT_ADDRESS: process.env.VITE_LOAN_CONTRACT_ADDRESS || "0x35B19024c0C7d740E7A6930C664Eb894cAb7F648",
  ADMIN_EMAIL: process.env.ADMIN_EMAIL || "kurubamahesh.cse@gmail.com",
};
