const { Pool } = require("pg");
const config = require("./environment");

let pool = null;

try {
  pool = new Pool({
    connectionString: config.DATABASE_URL,
    ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
  });
} catch (err) {
  console.warn("PostgreSQL connection not initialized directly. Fallback mode available.", err.message);
}

module.exports = {
  query: async (text, params) => {
    if (!pool) {
      throw new Error("Database pool is uninitialized.");
    }
    return pool.query(text, params);
  },
  pool,
};
