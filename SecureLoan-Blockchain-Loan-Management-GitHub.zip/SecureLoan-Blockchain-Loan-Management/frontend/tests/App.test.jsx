import { describe, it, expect } from "vitest";
import React from "react";
import App from "../src/App";

describe("Frontend App Component Suite", () => {
  it("should export App component properly", () => {
    expect(App).toBeDefined();
    expect(typeof App).toBe("function");
  });
});
