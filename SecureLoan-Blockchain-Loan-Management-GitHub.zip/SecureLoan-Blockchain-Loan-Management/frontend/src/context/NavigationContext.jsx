import React, { createContext, useContext, useState, useEffect } from "react";

const NavigationContext = createContext(null);

export const NavigationProvider = ({ children }) => {
  const [currentPath, setCurrentPath] = useState(
    typeof window !== "undefined" ? window.location.pathname || "/" : "/"
  );

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || "/");
    };
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  const navigate = (path) => {
    if (typeof window !== "undefined") {
      window.history.pushState({}, "", path);
      setCurrentPath(path);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const params = {};
  if (currentPath.startsWith("/loans/")) {
    params.id = currentPath.replace("/loans/", "");
  } else if (currentPath.startsWith("/admin/applications/")) {
    params.id = currentPath.replace("/admin/applications/", "");
  }

  return (
    <NavigationContext.Provider value={{ currentPath, navigate, params }}>
      {children}
    </NavigationContext.Provider>
  );
};

export const useNavigation = () => {
  const context = useContext(NavigationContext);
  if (!context) {
    throw new Error("useNavigation must be used within a NavigationProvider");
  }
  return context;
};
