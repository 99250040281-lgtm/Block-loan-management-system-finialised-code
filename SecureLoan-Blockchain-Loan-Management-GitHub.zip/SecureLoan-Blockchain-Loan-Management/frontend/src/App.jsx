import React from "react";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { NavigationProvider, useNavigation } from "./context/NavigationContext";
import Navbar from "./components/Navbar";

// Pages
import LandingPage from "./pages/LandingPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import BorrowerDashboard from "./pages/BorrowerDashboard";
import ApplyLoanPage from "./pages/ApplyLoanPage";
import MyLoansPage from "./pages/MyLoansPage";
import LoanDetailsPage from "./pages/LoanDetailsPage";
import RepaymentsPage from "./pages/RepaymentsPage";
import TransactionsPage from "./pages/TransactionsPage";

// Admin Pages
import AdminDashboard from "./pages/AdminDashboard";
import AdminApplicationsPage from "./pages/AdminApplicationsPage";
import AdminLoansPage from "./pages/AdminLoansPage";
import AdminTransactionsPage from "./pages/AdminTransactionsPage";
import AdminSettingsPage from "./pages/AdminSettingsPage";

const AppRoutes = () => {
  const { currentPath, navigate } = useNavigation();
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-400 text-sm">
        <span className="w-5 h-5 border-2 border-blue-500/20 border-t-blue-500 rounded-full animate-spin mr-3" />
        Initializing Secure Loan System...
      </div>
    );
  }

  // Public Routes
  if (currentPath === "/") return <LandingPage />;
  if (currentPath === "/login") return <LoginPage />;
  if (currentPath === "/register") return <RegisterPage />;

  // Require Auth
  if (!user) {
    return <LoginPage />;
  }

  const isAdmin = user.role === "admin" && user.email.toLowerCase() === "kurubamahesh.cse@gmail.com";

  // Admin Routes Guard
  if (currentPath.startsWith("/admin")) {
    if (!isAdmin) {
      return (
        <div className="max-w-md mx-auto my-20 p-8 bg-slate-900 border border-red-900/60 rounded-2xl text-center space-y-4 shadow-2xl">
          <h2 className="text-xl font-bold text-white">403 Forbidden: Administrator Privilege Required</h2>
          <p className="text-xs text-slate-400">
            Your account ({user.email}) is classified as a Borrower and cannot access administrative records.
          </p>
          <button
            onClick={() => navigate("/dashboard")}
            className="px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold cursor-pointer"
          >
            Go to Borrower Dashboard
          </button>
        </div>
      );
    }

    if (currentPath === "/admin") return <AdminDashboard />;
    if (currentPath.startsWith("/admin/applications")) return <AdminApplicationsPage />;
    if (currentPath === "/admin/loans") return <AdminLoansPage />;
    if (currentPath === "/admin/transactions") return <AdminTransactionsPage />;
    if (currentPath === "/admin/settings") return <AdminSettingsPage />;
    return <AdminDashboard />;
  }

  // Borrower Routes
  if (currentPath === "/dashboard") return <BorrowerDashboard />;
  if (currentPath === "/apply-loan") return <ApplyLoanPage />;
  if (currentPath === "/my-loans") return <MyLoansPage />;
  if (currentPath.startsWith("/loans/")) return <LoanDetailsPage />;
  if (currentPath === "/repayments") return <RepaymentsPage />;
  if (currentPath === "/transactions") return <TransactionsPage />;

  // Default redirect based on role
  return isAdmin ? <AdminDashboard /> : <BorrowerDashboard />;
};

export const App = () => {
  return (
    <AuthProvider>
      <NavigationProvider>
        <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
          <Navbar />
          <main className="flex-1">
            <AppRoutes />
          </main>
        </div>
      </NavigationProvider>
    </AuthProvider>
  );
};

export default App;
