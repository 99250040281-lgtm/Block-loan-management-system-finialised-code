import React, { useState, useEffect } from "react";
import { ShieldCheck, ExternalLink, RefreshCw, Cpu } from "lucide-react";
import contractService from "../services/contractService";

export const ContractStateWidget = () => {
  const [config, setConfig] = useState(contractService.getConfig());
  const [address, setAddress] = useState(null);

  useEffect(() => {
    contractService.getConnectedAddress().then((addr) => {
      setAddress(addr);
    });
  }, []);

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Cpu className="w-4 h-4 text-blue-400" />
          Blockchain Smart Contract State
        </h3>
        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          Sepolia Live
        </span>
      </div>

      <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 text-xs space-y-2">
        <div className="flex items-center justify-between text-slate-400">
          <span>Target Network:</span>
          <span className="text-slate-200 font-mono">Ethereum Sepolia (Chain ID 11155111)</span>
        </div>
        <div className="flex items-center justify-between text-slate-400">
          <span>Contract Address:</span>
          <a
            href={`${config.blockExplorerUrl}/address/${config.contractAddress}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-400 hover:text-blue-300 font-mono text-[11px] flex items-center gap-1"
          >
            {config.contractAddress
              ? `${config.contractAddress.slice(0, 8)}...${config.contractAddress.slice(-6)}`
              : "Not Configured"}
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
        <div className="flex items-center justify-between text-slate-400">
          <span>Signer Wallet:</span>
          <span className="text-slate-200 font-mono text-[11px]">
            {address ? `${address.slice(0, 6)}...${address.slice(-4)}` : "Disconnected"}
          </span>
        </div>
      </div>
    </div>
  );
};

export default ContractStateWidget;
