import React, { useState, useEffect } from "react";
import {
  ShieldCheck,
  Wallet,
  LogOut,
  User,
  LayoutDashboard,
  FilePlus,
  Coins,
  Receipt,
  FileText,
  Sliders,
  CheckCircle2,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useNavigation } from "../context/NavigationContext";
import contractService from "../services/contractService";

export const Navbar = () => {
  const { user, logout } = useAuth();
  const { currentPath, navigate } = useNavigation();
  const [walletAddress, setWalletAddress] = useState(null);
  const [connecting, setConnecting] = useState(false);

  useEffect(() => {
    contractService.getConnectedAddress().then((addr) => {
      setWalletAddress(addr);
    });
  }, []);

  const handleConnectWallet = async () => {
    try {
      setConnecting(true);
      const res = await contractService.connectWallet();
      setWalletAddress(res.address);
    } catch (err) {
      alert(err.message || "Failed to connect wallet.");
    } finally {
      setConnecting(false);
    }
  };

  const isAdmin = user && user.role === "admin" && user.email.toLowerCase() === "kurubamahesh.cse@gmail.com";

  return (
    <header className="sticky top-0 z-40 bg-slate-900/80 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div
          onClick={() => navigate("/")}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-lg shadow-blue-500/20 group-hover:scale-105 transition-transform">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <span className="font-bold text-sm text-white tracking-tight flex items-center gap-1.5">
              SecureLoan <span className="text-blue-400 font-mono text-xs">v1.0</span>
            </span>
            <p className="text-[10px] text-slate-400 font-medium">Smart Contract Loan System</p>
          </div>
        </div>

        {/* Navigation Links */}
        {user && (
          <nav className="hidden md:flex items-center gap-1">
            {!isAdmin ? (
              <>
                <button
                  onClick={() => navigate("/dashboard")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    currentPath === "/dashboard"
                      ? "bg-blue-600/10 text-blue-400 border border-blue-500/20"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  Dashboard
                </button>
                <button
                  onClick={() => navigate("/apply-loan")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    currentPath === "/apply-loan"
                      ? "bg-blue-600/10 text-blue-400 border border-blue-500/20"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  Apply Loan
                </button>
                <button
                  onClick={() => navigate("/my-loans")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    currentPath === "/my-loans"
                      ? "bg-blue-600/10 text-blue-400 border border-blue-500/20"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  My Loans
                </button>
                <button
                  onClick={() => navigate("/repayments")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    currentPath === "/repayments"
                      ? "bg-blue-600/10 text-blue-400 border border-blue-500/20"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  Repayments
                </button>
                <button
                  onClick={() => navigate("/transactions")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    currentPath === "/transactions"
                      ? "bg-blue-600/10 text-blue-400 border border-blue-500/20"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  Audit Trail
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => navigate("/admin")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    currentPath === "/admin"
                      ? "bg-blue-600/10 text-blue-400 border border-blue-500/20"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  Admin Console
                </button>
                <button
                  onClick={() => navigate("/admin/applications")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    currentPath.startsWith("/admin/applications")
                      ? "bg-blue-600/10 text-blue-400 border border-blue-500/20"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  Applications
                </button>
                <button
                  onClick={() => navigate("/admin/loans")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    currentPath === "/admin/loans"
                      ? "bg-blue-600/10 text-blue-400 border border-blue-500/20"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  Portfolio
                </button>
                <button
                  onClick={() => navigate("/admin/transactions")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    currentPath === "/admin/transactions"
                      ? "bg-blue-600/10 text-blue-400 border border-blue-500/20"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  Escrow Log
                </button>
                <button
                  onClick={() => navigate("/admin/settings")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    currentPath === "/admin/settings"
                      ? "bg-blue-600/10 text-blue-400 border border-blue-500/20"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  Settings
                </button>
              </>
            )}
          </nav>
        )}

        {/* Actions / Wallet / Auth */}
        <div className="flex items-center gap-3">
          {/* Wallet Button */}
          <button
            onClick={handleConnectWallet}
            disabled={connecting}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700/80 border border-slate-700 text-xs font-medium text-slate-200 transition-all cursor-pointer"
          >
            <Wallet className="w-3.5 h-3.5 text-blue-400" />
            <span>
              {walletAddress
                ? `${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}`
                : connecting
                ? "Connecting..."
                : "Connect Wallet"}
            </span>
          </button>

          {user ? (
            <div className="flex items-center gap-2">
              <span className="hidden sm:inline-block px-2.5 py-1 rounded-md text-[11px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                {isAdmin ? "Admin: Mahesh" : user.full_name || "Borrower"}
              </span>
              <button
                onClick={() => {
                  logout();
                  navigate("/");
                }}
                className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-rose-500/10 hover:text-rose-400 text-slate-400 border border-slate-700 transition-colors"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => navigate("/login")}
              className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-colors shadow-md shadow-blue-500/20"
            >
              Sign In
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
