import dbService from "./dbService";

const SESSION_USER_KEY = "secure_loan_session_user";
const CREDENTIALS_KEY = "secure_loan_credentials";
const ADMIN_EMAIL = "kurubamahesh.cse@gmail.com";

export class AuthService {
  constructor() {
    this.customSupabaseClient = null;
    this.initCredentials();
  }

  static getInstance() {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  initCredentials() {
    if (typeof window !== "undefined" && !localStorage.getItem(CREDENTIALS_KEY)) {
      localStorage.setItem(CREDENTIALS_KEY, JSON.stringify([]));
    }
  }

  getCredentials() {
    if (typeof window === "undefined") return [];
    const raw = localStorage.getItem(CREDENTIALS_KEY);
    return raw ? JSON.parse(raw) : [];
  }

  saveCredentials(creds) {
    if (typeof window !== "undefined") {
      localStorage.setItem(CREDENTIALS_KEY, JSON.stringify(creds));
    }
  }

  getCurrentUser() {
    if (typeof window === "undefined") return null;
    const raw = localStorage.getItem(SESSION_USER_KEY);
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw);
      return dbService.getProfileById(parsed.id) || parsed;
    } catch {
      return null;
    }
  }

  async login(email, password) {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !password) {
      throw new Error("Please enter both email and password.");
    }

    if (cleanEmail === ADMIN_EMAIL.toLowerCase()) {
      return this.loginAdmin(cleanEmail, password);
    }

    const creds = this.getCredentials();
    const match = creds.find((c) => c.email.toLowerCase() === cleanEmail);
    if (!match) {
      throw new Error("Account not found with this email. Please register as a borrower.");
    }
    if (match.passwordHash !== password) {
      throw new Error("Invalid password credentials. Please verify and try again.");
    }

    let profile = dbService.getProfileById(match.userId) || dbService.getProfileByEmail(cleanEmail);
    if (!profile) {
      profile = {
        id: match.userId,
        email: cleanEmail,
        full_name: cleanEmail.split("@")[0],
        role: "borrower",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      dbService.saveProfile(profile);
    }

    localStorage.setItem(SESSION_USER_KEY, JSON.stringify(profile));
    return profile;
  }

  loginAdmin(email, password) {
    const adminProfile = dbService.getProfileByEmail(ADMIN_EMAIL) || {
      id: "usr_admin_mahesh",
      email: ADMIN_EMAIL,
      full_name: "Mahesh",
      role: "admin",
      organization: "Administration Unit",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    dbService.saveProfile(adminProfile);
    localStorage.setItem(SESSION_USER_KEY, JSON.stringify(adminProfile));
    return adminProfile;
  }

  async register(params) {
    const cleanEmail = params.email.trim().toLowerCase();
    if (cleanEmail === ADMIN_EMAIL.toLowerCase()) {
      throw new Error("This email is reserved for institutional administration.");
    }

    const creds = this.getCredentials();
    if (creds.some((c) => c.email.toLowerCase() === cleanEmail)) {
      throw new Error("An account already exists with this email. Please log in.");
    }

    const userId = `usr_${Date.now()}`;
    const newProfile = {
      id: userId,
      email: cleanEmail,
      full_name: params.fullName,
      role: "borrower",
      phone: params.phone || "",
      wallet_address: params.walletAddress || "",
      organization: params.organization || "",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    dbService.saveProfile(newProfile);

    creds.push({
      userId,
      email: cleanEmail,
      passwordHash: params.password,
      created_at: new Date().toISOString(),
    });
    this.saveCredentials(creds);

    localStorage.setItem(SESSION_USER_KEY, JSON.stringify(newProfile));
    return newProfile;
  }

  logout() {
    if (typeof window !== "undefined") {
      localStorage.removeItem(SESSION_USER_KEY);
    }
  }
}

export default AuthService.getInstance();
