import { ethers } from "ethers";
import LoanManagementArtifact from "../../../blockchain/contracts/LoanManagement.json";

const CONTRACT_ABI = LoanManagementArtifact.abi;

export class ContractService {
  constructor() {
    this.provider = null;
    this.signer = null;
    this.contract = null;

    const savedAddress = typeof window !== "undefined" ? localStorage.getItem("loan_contract_address") : "";
    const isConfigured = Boolean(savedAddress && savedAddress !== "0x0000000000000000000000000000000000000000");

    this.config = {
      contractAddress: savedAddress || "0x35B19024c0C7d740E7A6930C664Eb894cAb7F648",
      chainId: 11155111,
      rpcUrl: "https://rpc.sepolia.org",
      blockExplorerUrl: "https://sepolia.etherscan.io",
      isConfigured: isConfigured || true,
    };
  }

  static getInstance() {
    if (!ContractService.instance) {
      ContractService.instance = new ContractService();
    }
    return ContractService.instance;
  }

  getConfig() {
    return { ...this.config };
  }

  updateConfig(updates) {
    const address = updates.contractAddress || this.config.contractAddress;
    const isConfigured = Boolean(address && address !== "0x0000000000000000000000000000000000000000");
    this.config = { ...this.config, ...updates, isConfigured };
    this.contract = null;
    if (typeof window !== "undefined") {
      localStorage.setItem("loan_contract_address", address);
    }
  }

  hasMetaMask() {
    return typeof window !== "undefined" && Boolean(window.ethereum);
  }

  async connectWallet() {
    if (!this.hasMetaMask()) {
      throw new Error("MetaMask is not installed. Please install MetaMask to interact with the blockchain.");
    }

    this.provider = new ethers.BrowserProvider(window.ethereum);
    const accounts = await this.provider.send("eth_requestAccounts", []);
    if (!accounts || accounts.length === 0) {
      throw new Error("No accounts selected in MetaMask.");
    }

    const network = await this.provider.getNetwork();
    this.signer = await this.provider.getSigner();

    if (this.config.isConfigured && this.config.contractAddress) {
      this.contract = new ethers.Contract(this.config.contractAddress, CONTRACT_ABI, this.signer);
    }

    return {
      address: accounts[0],
      chainId: Number(network.chainId),
    };
  }

  async getConnectedAddress() {
    if (!this.hasMetaMask()) return null;
    try {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const accounts = await provider.send("eth_accounts", []);
      return accounts.length > 0 ? accounts[0] : null;
    } catch {
      return null;
    }
  }

  async ensureContract() {
    if (!this.signer) {
      await this.connectWallet();
    }
    if (!this.contract && this.signer && this.config.contractAddress) {
      this.contract = new ethers.Contract(this.config.contractAddress, CONTRACT_ABI, this.signer);
    }
    if (!this.contract) {
      throw new Error("Contract instance not available. Please verify contract address configuration.");
    }
    return this.contract;
  }

  async applyLoanOnChain(amountEth, termMonths, interestRateBps, documentIpfsHash) {
    if (!this.config.isConfigured) return null;
    const contract = await this.ensureContract();
    const amountWei = ethers.parseEther(amountEth.toString());
    const tx = await contract.applyLoan(amountWei, termMonths, interestRateBps, documentIpfsHash);
    const receipt = await tx.wait();

    let loanId = null;
    for (const log of receipt.logs) {
      try {
        const parsed = contract.interface.parseLog(log);
        if (parsed && parsed.name === "LoanApplied") {
          loanId = Number(parsed.args[0]);
          break;
        }
      } catch {
        // ignore
      }
    }

    return { txHash: receipt.hash, loanId };
  }

  async approveLoanOnChain(loanId, remarks) {
    if (!this.config.isConfigured) return null;
    const contract = await this.ensureContract();
    const tx = await contract.approveLoan(loanId, remarks || "");
    const receipt = await tx.wait();
    return receipt.hash;
  }

  async rejectLoanOnChain(loanId, remarks) {
    if (!this.config.isConfigured) return null;
    const contract = await this.ensureContract();
    const tx = await contract.rejectLoan(loanId, remarks || "");
    const receipt = await tx.wait();
    return receipt.hash;
  }

  async fundLoanOnChain(loanId, amountEth) {
    if (!this.config.isConfigured) return null;
    const contract = await this.ensureContract();
    const amountWei = ethers.parseEther(amountEth.toString());
    const tx = await contract.fundLoan(loanId, { value: amountWei });
    const receipt = await tx.wait();
    return receipt.hash;
  }

  async makeRepaymentOnChain(loanId, amountEth) {
    if (!this.config.isConfigured) return null;
    const contract = await this.ensureContract();
    const amountWei = ethers.parseEther(amountEth.toString());
    const tx = await contract.makeRepayment(loanId, { value: amountWei });
    const receipt = await tx.wait();
    return receipt.hash;
  }

  async getLoan(loanId) {
    const contract = await this.ensureContract();
    return await contract.getLoan(loanId);
  }
}

export default ContractService.getInstance();
