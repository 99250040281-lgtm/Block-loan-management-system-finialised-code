/**
 * DatabaseService
 * Client-side persistence and reactivity layer with real-time BroadcastChannel synchronization
 * and hybrid Supabase / PostgreSQL capability.
 */

const DEFAULT_ADMIN = [
  {
    id: "usr_admin_mahesh",
    email: "kurubamahesh.cse@gmail.com",
    full_name: "Mahesh",
    role: "admin",
    phone: "+919876543210",
    wallet_address: "",
    organization: "Institutional Administration Unit",
    created_at: "2026-09-01T10:00:00.000Z",
    updated_at: "2026-09-01T10:00:00.000Z",
  },
];

export class DatabaseService {
  constructor() {
    this.listeners = new Set();
    this.broadcastChannel = null;
    this.initDatabase();
    this.initRealtime();
  }

  static getInstance() {
    if (!DatabaseService.instance) {
      DatabaseService.instance = new DatabaseService();
    }
    return DatabaseService.instance;
  }

  initRealtime() {
    if (typeof window !== "undefined") {
      try {
        this.broadcastChannel = new BroadcastChannel("secure_loan_realtime_channel");
        this.broadcastChannel.onmessage = (event) => {
          if (event.data && event.data.type === "APPLICATION_STATUS_CHANGED") {
            const payload = event.data.payload;
            this.listeners.forEach((listener) => {
              try {
                listener(payload);
              } catch (err) {
                console.error("Error in real-time listener:", err);
              }
            });
          }
        };
      } catch (err) {
        console.warn("BroadcastChannel not supported in environment:", err);
      }

      window.addEventListener("storage", (event) => {
        if (event.key === "secure_loan_sys_applications" && event.newValue) {
          try {
            const updatedList = JSON.parse(event.newValue);
            if (updatedList.length > 0) {
              this.listeners.forEach((listener) => {
                try {
                  listener({ eventType: "UPDATE", new: updatedList[0] });
                } catch (err) {
                  console.error(err);
                }
              });
            }
          } catch (e) {
            // ignore JSON parse error
          }
        }
      });
    }
  }

  subscribeToApplicationUpdates(callback) {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  dispatchRealtimeEvent(payload) {
    this.listeners.forEach((listener) => {
      try {
        listener(payload);
      } catch (err) {
        console.error("Error notifying realtime listener:", err);
      }
    });

    if (this.broadcastChannel) {
      try {
        this.broadcastChannel.postMessage({
          type: "APPLICATION_STATUS_CHANGED",
          payload,
        });
      } catch (e) {
        console.warn("BroadcastChannel postMessage note:", e);
      }
    }
  }

  initDatabase() {
    if (typeof window === "undefined") return;

    if (!localStorage.getItem("secure_loan_sys_profiles")) {
      localStorage.setItem("secure_loan_sys_profiles", JSON.stringify(DEFAULT_ADMIN));
    }
    if (!localStorage.getItem("secure_loan_sys_applications")) {
      localStorage.setItem("secure_loan_sys_applications", JSON.stringify([]));
    }
    if (!localStorage.getItem("secure_loan_sys_loans")) {
      localStorage.setItem("secure_loan_sys_loans", JSON.stringify([]));
    }
    if (!localStorage.getItem("secure_loan_sys_repayments")) {
      localStorage.setItem("secure_loan_sys_repayments", JSON.stringify([]));
    }
    if (!localStorage.getItem("secure_loan_sys_transactions")) {
      localStorage.setItem("secure_loan_sys_transactions", JSON.stringify([]));
    }
    if (!localStorage.getItem("secure_loan_sys_documents")) {
      localStorage.setItem("secure_loan_sys_documents", JSON.stringify([]));
    }
  }

  resetToCleanState() {
    if (typeof window === "undefined") return;
    localStorage.setItem("secure_loan_sys_profiles", JSON.stringify(DEFAULT_ADMIN));
    localStorage.setItem("secure_loan_sys_applications", JSON.stringify([]));
    localStorage.setItem("secure_loan_sys_loans", JSON.stringify([]));
    localStorage.setItem("secure_loan_sys_repayments", JSON.stringify([]));
    localStorage.setItem("secure_loan_sys_transactions", JSON.stringify([]));
    localStorage.setItem("secure_loan_sys_documents", JSON.stringify([]));
    localStorage.setItem("secure_loan_credentials", JSON.stringify([]));
    this.dispatchRealtimeEvent({ eventType: "DATABASE_RESET" });
  }

  getProfiles() {
    if (typeof window === "undefined") return DEFAULT_ADMIN;
    const raw = localStorage.getItem("secure_loan_sys_profiles");
    return raw ? JSON.parse(raw) : DEFAULT_ADMIN;
  }

  getProfileById(id) {
    return this.getProfiles().find((p) => p.id === id) || null;
  }

  getProfileByEmail(email) {
    const target = email.trim().toLowerCase();
    return target ? this.getProfiles().find((p) => p.email && p.email.trim().toLowerCase() === target) || null : null;
  }

  getAdmins() {
    return this.getProfiles().filter((p) => p.role === "admin" || p.role === "super_admin");
  }

  saveProfile(profile) {
    const isAdmin = profile.email.toLowerCase() === "kurubamahesh.cse@gmail.com" && profile.id === "usr_admin_mahesh";
    const updated = {
      ...profile,
      role: isAdmin ? "admin" : "borrower",
      updated_at: new Date().toISOString(),
    };
    const list = this.getProfiles();
    const idx = list.findIndex((p) => p.id === updated.id);
    if (idx >= 0) {
      list[idx] = updated;
    } else {
      list.push(updated);
    }
    localStorage.setItem("secure_loan_sys_profiles", JSON.stringify(list));
  }

  getApplications(user) {
    const raw = localStorage.getItem("secure_loan_sys_applications");
    const apps = raw ? JSON.parse(raw) : [];
    const profiles = this.getProfiles();
    const populated = apps.map((app) => ({
      ...app,
      borrower: profiles.find((p) => p.id === app.borrower_id),
      assigned_admin: app.admin_id ? profiles.find((p) => p.id === app.admin_id) : undefined,
    }));

    if (user.role === "borrower") {
      return populated.filter((a) => a.borrower_id === user.id);
    }
    if (user.role === "super_admin") {
      return populated;
    }
    if (user.role === "admin") {
      return populated.filter((a) => a.admin_id === user.id || a.admin_id === null);
    }
    return [];
  }

  getApplicationById(id, user) {
    return this.getApplications(user).find((a) => a.id === id) || null;
  }

  createApplication(user, data) {
    if (user.role !== "borrower") {
      throw new Error("Only registered borrowers can submit a loan application.");
    }

    const raw = localStorage.getItem("secure_loan_sys_applications");
    const apps = raw ? JSON.parse(raw) : [];
    const appNum = `APP-${new Date().getFullYear()}-${String(apps.length + 1).padStart(3, "0")}`;
    const newId = `app_${Date.now()}`;

    const newApp = {
      id: newId,
      application_number: appNum,
      borrower_id: user.id,
      admin_id: null,
      amount: Number(data.amount),
      purpose: data.purpose,
      term_months: Number(data.term_months),
      annual_income: Number(data.annual_income),
      employment_type: data.employment_type,
      employer_name: data.employer_name || "",
      credit_score: data.credit_score || 720,
      status: "PENDING",
      interest_rate_bps: 850,
      remarks: "",
      conditions: "",
      blockchain_loan_id: null,
      on_chain_tx_hash: null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    apps.unshift(newApp);
    localStorage.setItem("secure_loan_sys_applications", JSON.stringify(apps));

    if (data.documents && data.documents.length > 0) {
      for (const doc of data.documents) {
        this.addDocument({
          application_id: newId,
          borrower_id: user.id,
          document_type: doc.type,
          file_name: doc.name,
          file_size: doc.size,
          mime_type: doc.mimeType,
          file_url: doc.dataUrl,
        });
      }
    }

    this.dispatchRealtimeEvent({ eventType: "INSERT", new: newApp });
    return newApp;
  }

  assignAdmin(appId, adminId, user) {
    if (user.role !== "admin" && user.role !== "super_admin") {
      throw new Error("Unauthorized: Only administrators can assign loan applications.");
    }
    const raw = localStorage.getItem("secure_loan_sys_applications");
    const apps = raw ? JSON.parse(raw) : [];
    const idx = apps.findIndex((a) => a.id === appId);
    if (idx === -1) throw new Error("Loan application not found.");

    const app = apps[idx];
    if (app.admin_id && app.admin_id !== user.id && user.role !== "super_admin") {
      throw new Error("Permission Denied: This application is assigned to another administrator.");
    }

    app.admin_id = adminId;
    app.status = app.status === "PENDING" ? "UNDER_REVIEW" : app.status;
    app.updated_at = new Date().toISOString();
    apps[idx] = app;

    localStorage.setItem("secure_loan_sys_applications", JSON.stringify(apps));
    this.dispatchRealtimeEvent({ eventType: "UPDATE", new: app });
    return app;
  }

  approveApplication(appId, adminUser, params) {
    if (adminUser.role !== "admin" && adminUser.role !== "super_admin") {
      throw new Error("Unauthorized: Only administrators can approve loan applications.");
    }
    const raw = localStorage.getItem("secure_loan_sys_applications");
    const apps = raw ? JSON.parse(raw) : [];
    const idx = apps.findIndex((a) => a.id === appId);
    if (idx === -1) throw new Error("Loan application not found.");

    const app = apps[idx];
    if (app.admin_id && app.admin_id !== adminUser.id && adminUser.role !== "super_admin") {
      throw new Error("Access Denied: You are not the assigned administrator for this application.");
    }

    const principal = params.approved_amount || app.amount;
    const ratePercent = params.interest_rate || app.interest_rate_bps / 100;
    const totalRepayable = principal + ((ratePercent / 100) * principal * app.term_months) / 12;
    const monthlyInstallment = totalRepayable / app.term_months;

    app.status = "APPROVED";
    app.approved_amount = principal;
    app.interest_rate_bps = Math.round(ratePercent * 100);
    app.remarks = params.remarks || app.remarks;
    app.conditions = params.conditions || app.conditions;
    if (params.onChainTxHash) app.on_chain_tx_hash = params.onChainTxHash;
    if (params.blockchainLoanId) app.blockchain_loan_id = params.blockchainLoanId;
    app.updated_at = new Date().toISOString();

    apps[idx] = app;
    localStorage.setItem("secure_loan_sys_applications", JSON.stringify(apps));

    // Create active loan entry
    const rawLoans = localStorage.getItem("secure_loan_sys_loans");
    const loans = rawLoans ? JSON.parse(rawLoans) : [];
    const loanNum = `LN-${new Date().getFullYear()}-${String(loans.length + 1).padStart(3, "0")}`;

    const newLoan = {
      id: `loan_${Date.now()}`,
      loan_number: loanNum,
      application_id: app.id,
      borrower_id: app.borrower_id,
      principal_amount: principal,
      interest_rate: ratePercent,
      total_repayable: Math.round(totalRepayable * 100) / 100,
      remaining_balance: Math.round(totalRepayable * 100) / 100,
      monthly_installment: Math.round(monthlyInstallment * 100) / 100,
      term_months: app.term_months,
      start_date: new Date().toISOString().split("T")[0],
      due_date: new Date(Date.now() + app.term_months * 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      status: "ACTIVE",
      blockchain_loan_id: app.blockchain_loan_id,
      on_chain_tx_hash: params.onChainTxHash || null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    loans.unshift(newLoan);
    localStorage.setItem("secure_loan_sys_loans", JSON.stringify(loans));

    const borrowerProfile = this.getProfileById(app.borrower_id);
    this.addTransaction({
      loan_id: newLoan.id,
      application_id: app.id,
      borrower_id: app.borrower_id,
      borrower_name: borrowerProfile?.full_name || "Borrower",
      type: "DISBURSEMENT",
      amount: principal,
      status: "COMPLETED",
      tx_hash: params.onChainTxHash || null,
      network: params.onChainTxHash ? "Ethereum Sepolia Testnet" : "Internal Escrow Disbursement",
    });

    this.dispatchRealtimeEvent({ eventType: "UPDATE", new: app });
    return { application: app, loan: newLoan };
  }

  rejectApplication(appId, adminUser, remarks, onChainTxHash) {
    if (adminUser.role !== "admin" && adminUser.role !== "super_admin") {
      throw new Error("Unauthorized: Only administrators can reject loan applications.");
    }
    const raw = localStorage.getItem("secure_loan_sys_applications");
    const apps = raw ? JSON.parse(raw) : [];
    const idx = apps.findIndex((a) => a.id === appId);
    if (idx === -1) throw new Error("Loan application not found.");

    const app = apps[idx];
    if (app.admin_id && app.admin_id !== adminUser.id && adminUser.role !== "super_admin") {
      throw new Error("Access Denied: You are not the assigned administrator for this application.");
    }

    app.status = "REJECTED";
    app.remarks = remarks;
    if (onChainTxHash) app.on_chain_tx_hash = onChainTxHash;
    app.updated_at = new Date().toISOString();

    apps[idx] = app;
    localStorage.setItem("secure_loan_sys_applications", JSON.stringify(apps));
    this.dispatchRealtimeEvent({ eventType: "UPDATE", new: app });
    return app;
  }

  getLoans(user) {
    const raw = localStorage.getItem("secure_loan_sys_loans");
    const loans = raw ? JSON.parse(raw) : [];
    const profiles = this.getProfiles();
    const populated = loans.map((l) => ({
      ...l,
      borrower: profiles.find((p) => p.id === l.borrower_id),
    }));

    if (user.role === "borrower") {
      return populated.filter((l) => l.borrower_id === user.id);
    }
    return populated;
  }

  getLoanById(id, user) {
    return this.getLoans(user).find((l) => l.id === id) || null;
  }

  getRepayments(user, loanId) {
    const raw = localStorage.getItem("secure_loan_sys_repayments");
    let repayments = raw ? JSON.parse(raw) : [];
    if (user.role === "borrower") {
      repayments = repayments.filter((r) => r.borrower_id === user.id);
    }
    if (loanId) {
      repayments = repayments.filter((r) => r.loan_id === loanId);
    }
    return repayments.sort((a, b) => new Date(b.payment_date).getTime() - new Date(a.payment_date).getTime());
  }

  makeRepayment(loanId, user, amount, paymentMethod, onChainTxHash, notes) {
    const rawLoans = localStorage.getItem("secure_loan_sys_loans");
    const loans = rawLoans ? JSON.parse(rawLoans) : [];
    const idx = loans.findIndex((l) => l.id === loanId);
    if (idx === -1) throw new Error("Loan not found.");

    const loan = loans[idx];
    if (user.role === "borrower" && loan.borrower_id !== user.id) {
      throw new Error("Unauthorized: You can only make repayments on your own loans.");
    }
    if (loan.remaining_balance <= 0) {
      throw new Error("This loan has already been fully settled.");
    }

    const payAmount = Math.min(amount, loan.remaining_balance);
    const rate = loan.interest_rate / 100;
    const interestPortion = Math.round(payAmount * (rate / (1 + rate)) * 100) / 100;
    const principalPortion = Math.round((payAmount - interestPortion) * 100) / 100;

    const rawRepayments = localStorage.getItem("secure_loan_sys_repayments");
    const repayments = rawRepayments ? JSON.parse(rawRepayments) : [];
    const existingForLoan = repayments.filter((r) => r.loan_id === loanId);

    const newRepayment = {
      id: `rep_${Date.now()}`,
      loan_id: loan.id,
      borrower_id: loan.borrower_id,
      installment_number: existingForLoan.length + 1,
      amount: payAmount,
      principal_paid: principalPortion,
      interest_paid: interestPortion,
      payment_method: paymentMethod,
      status: "PAID",
      payment_date: new Date().toISOString(),
      on_chain_tx_hash: onChainTxHash || null,
      receipt_url: `/receipts/REC-${Date.now().toString().slice(-6)}.pdf`,
      notes: notes || `Installment #${existingForLoan.length + 1} settled`,
      created_at: new Date().toISOString(),
    };

    repayments.unshift(newRepayment);
    localStorage.setItem("secure_loan_sys_repayments", JSON.stringify(repayments));

    loan.remaining_balance = Math.max(0, Math.round((loan.remaining_balance - payAmount) * 100) / 100);
    if (loan.remaining_balance === 0) {
      loan.status = "COMPLETED";
    }
    loan.updated_at = new Date().toISOString();
    loans[idx] = loan;
    localStorage.setItem("secure_loan_sys_loans", JSON.stringify(loans));

    const borrowerProfile = this.getProfileById(loan.borrower_id);
    this.addTransaction({
      loan_id: loan.id,
      borrower_id: loan.borrower_id,
      borrower_name: borrowerProfile?.full_name || "Borrower",
      type: "REPAYMENT",
      amount: payAmount,
      status: "COMPLETED",
      tx_hash: onChainTxHash || null,
      network: onChainTxHash ? "Ethereum Sepolia Testnet" : "Secure Loan Payment Clearing",
    });

    return { repayment: newRepayment, loan };
  }

  getTransactions(user) {
    const raw = localStorage.getItem("secure_loan_sys_transactions");
    let txs = raw ? JSON.parse(raw) : [];
    if (user.role === "borrower") {
      txs = txs.filter((t) => t.borrower_id === user.id);
    }
    return txs.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  addTransaction(data) {
    const raw = localStorage.getItem("secure_loan_sys_transactions");
    const txs = raw ? JSON.parse(raw) : [];
    const newTx = {
      ...data,
      id: `tx_${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    txs.unshift(newTx);
    localStorage.setItem("secure_loan_sys_transactions", JSON.stringify(txs));
    return newTx;
  }

  getDocuments(user, appId) {
    const raw = localStorage.getItem("secure_loan_sys_documents");
    let docs = raw ? JSON.parse(raw) : [];
    if (user.role === "borrower") {
      docs = docs.filter((d) => d.borrower_id === user.id);
    }
    if (appId) {
      docs = docs.filter((d) => d.application_id === appId);
    }
    return docs;
  }

  addDocument(data) {
    const raw = localStorage.getItem("secure_loan_sys_documents");
    const docs = raw ? JSON.parse(raw) : [];
    const newDoc = {
      ...data,
      id: `doc_${Date.now()}_${docs.length + 1}`,
      verification_status: "PENDING",
      created_at: new Date().toISOString(),
    };
    docs.unshift(newDoc);
    localStorage.setItem("secure_loan_sys_documents", JSON.stringify(docs));
    return newDoc;
  }

  verifyDocument(docId, adminUser, status, remarks) {
    if (adminUser.role !== "admin" && adminUser.role !== "super_admin") {
      throw new Error("Unauthorized: Only administrators can verify documents.");
    }
    const raw = localStorage.getItem("secure_loan_sys_documents");
    const docs = raw ? JSON.parse(raw) : [];
    const idx = docs.findIndex((d) => d.id === docId);
    if (idx === -1) throw new Error("Document record not found.");

    const doc = docs[idx];
    doc.verification_status = status;
    doc.remarks = remarks || (status === "VERIFIED" ? "Verified by Administrator" : "Document rejected");
    doc.verified_by = adminUser.id;
    doc.verified_at = new Date().toISOString();
    docs[idx] = doc;
    localStorage.setItem("secure_loan_sys_documents", JSON.stringify(docs));
    return doc;
  }

  getBorrowerMetrics(user) {
    if (user.role !== "borrower") {
      return {
        totalApplications: 0,
        activeLoansCount: 0,
        totalOutstanding: 0,
        totalRepaid: 0,
        nextRepaymentAmount: 0,
        nextDueDate: null,
      };
    }

    const apps = this.getApplications(user);
    const loans = this.getLoans(user).filter((l) => l.status === "ACTIVE");
    const repayments = this.getRepayments(user);

    const totalOutstanding = loans.reduce((acc, l) => acc + l.remaining_balance, 0);
    const totalRepaid = repayments.filter((r) => r.status === "PAID").reduce((acc, r) => acc + r.amount, 0);
    const firstActive = loans[0];

    return {
      totalApplications: apps.length,
      activeLoansCount: loans.length,
      totalOutstanding: Math.round(totalOutstanding * 100) / 100,
      totalRepaid: Math.round(totalRepaid * 100) / 100,
      nextRepaymentAmount: firstActive ? firstActive.monthly_installment : 0,
      nextDueDate: firstActive ? firstActive.due_date : null,
    };
  }

  getAdminMetrics(user) {
    const raw = localStorage.getItem("secure_loan_sys_applications");
    const apps = raw ? JSON.parse(raw) : [];
    const loans = this.getLoans(user);
    const repayments = this.getRepayments(user);

    const assigned = apps.filter((a) => a.admin_id === user.id);
    const unassigned = apps.filter((a) => a.admin_id === null);

    const pending = assigned.filter((a) => a.status === "PENDING" || a.status === "UNDER_REVIEW").length;
    const approved = assigned.filter((a) => a.status === "APPROVED" || a.status === "ACTIVE").length;
    const rejected = assigned.filter((a) => a.status === "REJECTED").length;

    const totalDisbursed = loans.reduce((acc, l) => acc + l.principal_amount, 0);
    const totalCollected = repayments.filter((r) => r.status === "PAID").reduce((acc, r) => acc + r.amount, 0);
    const totalOutstanding = loans.filter((l) => l.status === "ACTIVE").reduce((acc, l) => acc + l.remaining_balance, 0);

    return {
      assignedApplicationsCount: assigned.length,
      unassignedPoolCount: unassigned.length,
      pendingReviewsCount: pending,
      approvedCount: approved,
      rejectedCount: rejected,
      activeLoansCount: loans.filter((l) => l.status === "ACTIVE").length,
      completedLoansCount: loans.filter((l) => l.status === "COMPLETED").length,
      totalDisbursed: Math.round(totalDisbursed * 100) / 100,
      totalCollected: Math.round(totalCollected * 100) / 100,
      totalOutstanding: Math.round(totalOutstanding * 100) / 100,
    };
  }
}

export default DatabaseService.getInstance();
