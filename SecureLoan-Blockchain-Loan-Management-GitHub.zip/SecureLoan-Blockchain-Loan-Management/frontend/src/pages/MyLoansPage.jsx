import React, { useState, useEffect } from "react";
import { Coins, Filter, Search, ArrowRight, ExternalLink } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useNavigation } from "../context/NavigationContext";
import dbService from "../services/dbService";
import StatusBadge from "../components/StatusBadge";

export const MyLoansPage = () => {
  const { user } = useAuth();
  const { navigate } = useNavigation();

  const [applications, setApplications] = useState([]);
  const [filter, setFilter] = useState("ALL");

  useEffect(() => {
    if (user) {
      loadData();
      return dbService.subscribeToApplicationUpdates(loadData);
    }
  }, [user]);

  const loadData = () => {
    setApplications(dbService.getApplications(user));
  };

  const filtered = applications.filter((app) => {
    if (filter === "ALL") return true;
    return app.status === filter;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">My Loan Applications</h1>
          <p className="text-xs text-slate-400">
            Track status, administrator review notes, and blockchain contract state for all your submissions.
          </p>
        </div>

        <button
          onClick={() => navigate("/apply-loan")}
          className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-colors self-start sm:self-auto cursor-pointer"
        >
          + New Loan Application
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 text-xs font-semibold">
        {["ALL", "PENDING", "UNDER_REVIEW", "APPROVED", "ACTIVE", "REJECTED"].map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              filter === tab
                ? "bg-blue-600 text-white"
                : "bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            {tab.replace("_", " ")}
          </button>
        ))}
      </div>

      {/* Applications List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        {filtered.length === 0 ? (
          <div className="p-16 text-center text-slate-500 text-xs">
            No applications found matching the selected filter.
          </div>
        ) : (
          <div className="divide-y divide-slate-800">
            {filtered.map((app) => (
              <div
                key={app.id}
                className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-800/40 transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white font-mono">{app.application_number}</span>
                    <StatusBadge status={app.status} />
                  </div>
                  <p className="text-xs text-slate-400">{app.purpose}</p>
                  <p className="text-[11px] text-slate-500">
                    Submitted: {new Date(app.created_at).toLocaleDateString()} | Term: {app.term_months} Months
                  </p>
                  {app.remarks && (
                    <p className="text-[11px] text-blue-400 italic">
                      Reviewer Note: "{app.remarks}"
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <span className="text-xs text-slate-400">Principal</span>
                    <div className="font-mono font-bold text-white text-base">
                      ${app.amount.toLocaleString()}
                    </div>
                  </div>

                  {app.status === "ACTIVE" || app.status === "APPROVED" ? (
                    <button
                      onClick={() => {
                        const matchingLoan = dbService.getLoans(user).find((l) => l.application_id === app.id);
                        if (matchingLoan) {
                          navigate(`/loans/${matchingLoan.id}`);
                        } else {
                          navigate("/repayments");
                        }
                      }}
                      className="px-4 py-2 rounded-xl bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 border border-blue-500/20 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                    >
                      View Loan Details <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MyLoansPage;
