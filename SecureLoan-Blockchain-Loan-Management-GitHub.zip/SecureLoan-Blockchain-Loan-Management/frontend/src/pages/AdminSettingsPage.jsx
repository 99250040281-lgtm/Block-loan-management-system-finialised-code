import React, { useState } from "react";
import { Sliders, ShieldAlert, CheckCircle2, RefreshCw } from "lucide-react";
import contractService from "../services/contractService";
import dbService from "../services/dbService";

export const AdminSettingsPage = () => {
  const [config, setConfig] = useState(contractService.getConfig());
  const [contractAddress, setContractAddress] = useState(config.contractAddress);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveContract = (e) => {
    e.preventDefault();
    contractService.updateConfig({ contractAddress });
    setConfig(contractService.getConfig());
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleResetDatabase = () => {
    if (
      window.confirm(
        "Are you sure you want to reset the database to clean 0-state? This will clear local test applications, loans, and non-admin profiles."
      )
    ) {
      dbService.resetToCleanState();
      alert("Database has been reset to default initial state.");
      window.location.reload();
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
          <Sliders className="w-6 h-6 text-blue-400" />
          System Settings & Contract Configuration
        </h1>
        <p className="text-xs text-slate-400">
          Configure on-chain smart contract parameters, Ethereum networks, and database state.
        </p>
      </div>

      {savedSuccess && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" /> Smart contract configuration updated successfully.
        </div>
      )}

      {/* Contract Settings */}
      <form onSubmit={handleSaveContract} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <h2 className="text-sm font-bold text-white">Smart Contract Address</h2>
        <p className="text-xs text-slate-400">
          Set the deployed Solidity 0.8.20 contract address on Sepolia testnet.
        </p>

        <div className="space-y-1">
          <label className="text-xs text-slate-400">Ethereum Sepolia Contract Address</label>
          <input
            type="text"
            required
            value={contractAddress}
            onChange={(e) => setContractAddress(e.target.value)}
            placeholder="0x..."
            className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono"
          />
        </div>

        <button
          type="submit"
          className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-md shadow-blue-500/20 cursor-pointer"
        >
          Save Contract Configuration
        </button>
      </form>

      {/* Danger Zone: Database Reset */}
      <div className="bg-slate-900 border border-rose-900/40 rounded-2xl p-6 space-y-4">
        <h2 className="text-sm font-bold text-rose-400 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-rose-400" />
          Maintenance & Zero-State Database Reset
        </h2>
        <p className="text-xs text-slate-400">
          Purges mock applications, loans, and repayments while preserving institutional administrator Mahesh's account.
        </p>

        <button
          type="button"
          onClick={handleResetDatabase}
          className="px-4 py-2 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-700/50 text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Reset Database to 0-State
        </button>
      </div>
    </div>
  );
};

export default AdminSettingsPage;
