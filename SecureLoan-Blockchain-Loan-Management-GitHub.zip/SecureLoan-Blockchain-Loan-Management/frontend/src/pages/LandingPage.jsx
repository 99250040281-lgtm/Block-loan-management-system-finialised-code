import React from "react";
import {
  ShieldCheck,
  Cpu,
  Lock,
  ArrowRight,
  Coins,
  CheckCircle2,
  FileCheck2,
  Building,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useNavigation } from "../context/NavigationContext";
import ContractStateWidget from "../components/ContractStateWidget";

export const LandingPage = () => {
  const { user } = useAuth();
  const { navigate } = useNavigation();

  return (
    <div className="relative overflow-hidden py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-16">
      {/* Hero */}
      <div className="text-center space-y-6 max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
          <Cpu className="w-3.5 h-3.5" />
          Powered by Ethereum Smart Contracts (Solidity 0.8.20)
        </div>

        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight">
          Blockchain-Based Secure <br />
          <span className="bg-gradient-to-r from-blue-400 via-indigo-400 to-cyan-400 bg-clip-text text-transparent">
            Loan Management System
          </span>
        </h1>

        <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
          Decentralized verification, cryptographic document trails, automated repayment calculation,
          and role-based administrator access. Designed for tamper-evident lending operations.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
          {user ? (
            <button
              onClick={() =>
                navigate(user.role === "admin" ? "/admin" : "/dashboard")
              }
              className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm flex items-center gap-2 shadow-lg shadow-blue-500/25 transition-all cursor-pointer"
            >
              Go to {user.role === "admin" ? "Admin Portal" : "Borrower Portal"}
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <>
              <button
                onClick={() => navigate("/login")}
                className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm flex items-center gap-2 shadow-lg shadow-blue-500/25 transition-all cursor-pointer"
              >
                Sign In to System
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => navigate("/register")}
                className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-sm transition-all cursor-pointer"
              >
                Register as Borrower
              </button>
            </>
          )}
        </div>
      </div>

      {/* Feature Highlights Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center border border-blue-500/20">
            <Lock className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-white text-base">Immutable Smart Contracts</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            All loan terms, interest rates (basis points), and approvals are committed on Ethereum testnet
            with non-repudiable transaction logs.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center border border-indigo-500/20">
            <Building className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-white text-base">Role-Based Loan Workflow</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Assigned administrator review prevents unauthorized approvals. Institutional administrator
            governance ensures compliant disbursement.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center border border-cyan-500/20">
            <Coins className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-white text-base">Transparent Repayments</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Borrowers settle installments on-chain or via escrow clearing with real-time balance reduction
            and automated completion milestones.
          </p>
        </div>
      </div>

      {/* Contract State Box */}
      <div className="max-w-xl mx-auto">
        <ContractStateWidget />
      </div>
    </div>
  );
};

export default LandingPage;
