import React, { useState } from "react";
import {
  FilePlus,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  DollarSign,
  Calendar,
  Building,
  Upload,
  ShieldCheck,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useNavigation } from "../context/NavigationContext";
import dbService from "../services/dbService";
import contractService from "../services/contractService";

export const ApplyLoanPage = () => {
  const { user } = useAuth();
  const { navigate } = useNavigation();

  const [step, setStep] = useState(1);
  const [amount, setAmount] = useState(15000);
  const [termMonths, setTermMonths] = useState(24);
  const [purpose, setPurpose] = useState("Home Renovation & Green Energy");
  const [annualIncome, setAnnualIncome] = useState(85000);
  const [employmentType, setEmploymentType] = useState("Full-Time");
  const [employerName, setEmployerName] = useState("Acme Corp");
  const [creditScore, setCreditScore] = useState(740);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);

  // Interest calculation (8.5% default)
  const interestRateBps = 850;
  const interestRatePercent = 8.5;
  const totalInterest = (amount * (interestRatePercent / 100) * termMonths) / 12;
  const totalRepayable = amount + totalInterest;
  const monthlyInstallment = totalRepayable / termMonths;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitError(null);
    setSubmitting(true);

    try {
      // Create off-chain record with reactive DB
      const appRecord = dbService.createApplication(user, {
        amount,
        term_months: termMonths,
        purpose,
        annual_income: annualIncome,
        employment_type: employmentType,
        employer_name: employerName,
        credit_score: creditScore,
        documents: [
          {
            name: "income_proof.pdf",
            type: "INCOME_VERIFICATION",
            size: 245000,
            mimeType: "application/pdf",
            dataUrl: "data:application/pdf;base64,JVBERi0xLjQK...",
          },
        ],
      });

      // Try on-chain smart contract interaction if wallet is connected
      try {
        const dummyIpfs = "QmZtmD2qtQgX2qM2BqS5eXZn9T8L4DkE3qX9F2a1b0c9d8";
        const onChainRes = await contractService.applyLoanOnChain(
          amount / 1000, // scaled eth or direct
          termMonths,
          interestRateBps,
          dummyIpfs
        );
        if (onChainRes && onChainRes.txHash) {
          appRecord.on_chain_tx_hash = onChainRes.txHash;
          appRecord.blockchain_loan_id = onChainRes.loanId;
        }
      } catch (chainErr) {
        console.warn("On-chain registration note:", chainErr.message);
      }

      navigate("/my-loans");
    } catch (err) {
      setSubmitError(err.message || "Failed to submit loan application.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">New Loan Application</h1>
        <p className="text-xs text-slate-400">
          Complete the guided steps below. All submitted applications are logged with cryptographic audit records.
        </p>
      </div>

      {/* Progress steps */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 text-xs font-medium">
        <div className={`flex items-center gap-2 ${step >= 1 ? "text-blue-400" : "text-slate-500"}`}>
          <span className="w-6 h-6 rounded-full border flex items-center justify-center text-[11px] font-bold">1</span>
          Borrower Info
        </div>
        <div className={`flex items-center gap-2 ${step >= 2 ? "text-blue-400" : "text-slate-500"}`}>
          <span className="w-6 h-6 rounded-full border flex items-center justify-center text-[11px] font-bold">2</span>
          Income & Employment
        </div>
        <div className={`flex items-center gap-2 ${step >= 3 ? "text-blue-400" : "text-slate-500"}`}>
          <span className="w-6 h-6 rounded-full border flex items-center justify-center text-[11px] font-bold">3</span>
          Loan Parameters
        </div>
        <div className={`flex items-center gap-2 ${step >= 4 ? "text-blue-400" : "text-slate-500"}`}>
          <span className="w-6 h-6 rounded-full border flex items-center justify-center text-[11px] font-bold">4</span>
          Confirmation
        </div>
      </div>

      {submitError && (
        <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs">
          {submitError}
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
        {step === 1 && (
          <div className="space-y-4">
            <h2 className="text-sm font-bold text-white">Step 1: Borrower Personal Information</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs text-slate-400">Full Name</label>
                <input
                  type="text"
                  disabled
                  value={user?.full_name || ""}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-400"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs text-slate-400">Registered Email</label>
                <input
                  type="text"
                  disabled
                  value={user?.email || ""}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-400"
                />
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-xs text-slate-400">Purpose of Loan</label>
              <input
                type="text"
                required
                value={purpose}
                onChange={(e) => setPurpose(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200"
              />
            </div>
            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-2"
              >
                Next: Income Details <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <h2 className="text-sm font-bold text-white">Step 2: Income & Employment Details</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs text-slate-400">Annual Income ($)</label>
                <input
                  type="number"
                  required
                  value={annualIncome}
                  onChange={(e) => setAnnualIncome(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs text-slate-400">Employment Status</label>
                <select
                  value={employmentType}
                  onChange={(e) => setEmploymentType(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200"
                >
                  <option value="Full-Time">Full-Time Employed</option>
                  <option value="Part-Time">Part-Time Employed</option>
                  <option value="Self-Employed">Self-Employed / Business</option>
                  <option value="Contractor">Contractor / Freelancer</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs text-slate-400">Employer / Business Name</label>
                <input
                  type="text"
                  value={employerName}
                  onChange={(e) => setEmployerName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs text-slate-400">Estimated Credit Score</label>
                <input
                  type="number"
                  value={creditScore}
                  onChange={(e) => setCreditScore(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono"
                />
              </div>
            </div>
            <div className="flex justify-between pt-2">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold flex items-center gap-2"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back
              </button>
              <button
                type="button"
                onClick={() => setStep(3)}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-2"
              >
                Next: Loan Terms <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <h2 className="text-sm font-bold text-white">Step 3: Loan Parameters & Terms</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs text-slate-400">Requested Principal ($)</label>
                <input
                  type="number"
                  required
                  min="500"
                  max="500000"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs text-slate-400">Term (Months)</label>
                <select
                  value={termMonths}
                  onChange={(e) => setTermMonths(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200"
                >
                  <option value="6">6 Months</option>
                  <option value="12">12 Months (1 Year)</option>
                  <option value="24">24 Months (2 Years)</option>
                  <option value="36">36 Months (3 Years)</option>
                  <option value="48">48 Months (4 Years)</option>
                  <option value="60">60 Months (5 Years)</option>
                </select>
              </div>
            </div>

            {/* Calculations Card */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Standard APR Rate:</span>
                <span className="text-slate-200 font-mono">{interestRatePercent}%</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Total Calculated Interest:</span>
                <span className="text-slate-200 font-mono">${Math.round(totalInterest).toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-400 font-bold">
                <span>Estimated Monthly Installment:</span>
                <span className="text-blue-400 font-mono">${Math.round(monthlyInstallment).toLocaleString()}/mo</span>
              </div>
            </div>

            <div className="flex justify-between pt-2">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold flex items-center gap-2"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back
              </button>
              <button
                type="button"
                onClick={() => setStep(4)}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-2"
              >
                Review & Confirm <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-4">
            <h2 className="text-sm font-bold text-white">Step 4: Smart Contract Confirmation</h2>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Applicant:</span>
                <span className="text-slate-200">{user?.full_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Principal Amount:</span>
                <span className="text-blue-400 font-bold font-mono">${amount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Duration:</span>
                <span className="text-slate-200">{termMonths} Months</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Total Repayable:</span>
                <span className="text-emerald-400 font-bold font-mono">${Math.round(totalRepayable).toLocaleString()}</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>
                By submitting, a cryptographic record will be recorded in the system ledger and queued for administrator underwriting.
              </span>
            </div>

            <div className="flex justify-between pt-2">
              <button
                type="button"
                onClick={() => setStep(3)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold flex items-center gap-2"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-blue-500/25 cursor-pointer disabled:opacity-50"
              >
                {submitting ? "Submitting Application..." : "Submit Application"}
              </button>
            </div>
          </div>
        )}
      </form>
    </div>
  );
};

export default ApplyLoanPage;
