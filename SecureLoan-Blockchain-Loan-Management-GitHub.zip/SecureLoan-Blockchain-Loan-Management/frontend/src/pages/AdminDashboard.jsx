import React, { useState, useEffect } from "react";
import {
  ShieldCheck,
  FileCheck2,
  Coins,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRight,
  TrendingUp,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useNavigation } from "../context/NavigationContext";
import dbService from "../services/dbService";
import StatusBadge from "../components/StatusBadge";
import ContractStateWidget from "../components/ContractStateWidget";

export const AdminDashboard = () => {
  const { user } = useAuth();
  const { navigate } = useNavigation();

  const [metrics, setMetrics] = useState({
    assignedApplicationsCount: 0,
    unassignedPoolCount: 0,
    pendingReviewsCount: 0,
    approvedCount: 0,
    rejectedCount: 0,
    activeLoansCount: 0,
    completedLoansCount: 0,
    totalDisbursed: 0,
    totalCollected: 0,
    totalOutstanding: 0,
  });
  const [pendingApps, setPendingApps] = useState([]);

  useEffect(() => {
    if (user) {
      loadData();
      return dbService.subscribeToApplicationUpdates(loadData);
    }
  }, [user]);

  const loadData = () => {
    setMetrics(dbService.getAdminMetrics(user));
    const all = dbService.getApplications(user);
    setPendingApps(all.filter((a) => a.status === "PENDING" || a.status === "UNDER_REVIEW"));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-blue-400" />
            Institutional Administration Portal
          </h1>
          <p className="text-xs text-slate-400">
            Institutional Administrator: <span className="text-white font-medium">Mahesh</span> (kurubamahesh.cse@gmail.com)
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate("/admin/applications")}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-md shadow-blue-500/20 cursor-pointer"
          >
            Review Applications ({metrics.pendingReviewsCount})
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <span className="text-xs font-medium text-slate-400">Pending Review Queue</span>
          <div className="text-2xl font-bold text-amber-400">{metrics.pendingReviewsCount}</div>
          <p className="text-[11px] text-slate-500">{metrics.unassignedPoolCount} unassigned in pool</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <span className="text-xs font-medium text-slate-400">Active Serviced Loans</span>
          <div className="text-2xl font-bold text-blue-400">{metrics.activeLoansCount}</div>
          <p className="text-[11px] text-slate-500">{metrics.completedLoansCount} loans fully completed</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <span className="text-xs font-medium text-slate-400">Total Capital Disbursed</span>
          <div className="text-2xl font-bold text-white font-mono">
            ${metrics.totalDisbursed.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500">Funded on-chain & escrow</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <span className="text-xs font-medium text-slate-400">Total Capital Collected</span>
          <div className="text-2xl font-bold text-emerald-400 font-mono">
            ${metrics.totalCollected.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500">${metrics.totalOutstanding.toLocaleString()} outstanding</p>
        </div>
      </div>

      {/* Pending Applications Review Queue */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <FileCheck2 className="w-5 h-5 text-amber-400" />
              Pending Application Reviews ({pendingApps.length})
            </h2>
            <button
              onClick={() => navigate("/admin/applications")}
              className="text-xs text-blue-400 hover:text-blue-300 font-semibold"
            >
              View All Queue →
            </button>
          </div>

          {pendingApps.length === 0 ? (
            <div className="p-12 text-center text-slate-500 text-xs">
              All applications are currently up to date. No pending reviews in queue.
            </div>
          ) : (
            <div className="divide-y divide-slate-800">
              {pendingApps.slice(0, 5).map((app) => (
                <div key={app.id} className="py-4 flex items-center justify-between text-xs">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white font-mono">{app.application_number}</span>
                      <StatusBadge status={app.status} />
                    </div>
                    <p className="text-slate-400 mt-0.5">
                      Borrower: {app.borrower?.full_name || "Applicant"} | Purpose: {app.purpose}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Amount: <span className="font-mono text-white font-bold">${app.amount.toLocaleString()}</span> | Score: {app.credit_score}
                    </p>
                  </div>

                  <button
                    onClick={() => navigate("/admin/applications")}
                    className="px-3 py-1.5 rounded-lg bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 border border-blue-500/20 font-semibold cursor-pointer"
                  >
                    Review & Underwrite
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div>
          <ContractStateWidget />
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
