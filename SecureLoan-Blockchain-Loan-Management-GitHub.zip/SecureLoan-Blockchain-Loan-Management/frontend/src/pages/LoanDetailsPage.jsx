import React, { useState, useEffect } from "react";
import {
  Coins,
  ArrowLeft,
  CheckCircle2,
  Calendar,
  ExternalLink,
  ShieldCheck,
  CreditCard,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useNavigation } from "../context/NavigationContext";
import dbService from "../services/dbService";
import contractService from "../services/contractService";
import StatusBadge from "../components/StatusBadge";

export const LoanDetailsPage = () => {
  const { user } = useAuth();
  const { params, navigate } = useNavigation();

  const [loan, setLoan] = useState(null);
  const [repayments, setRepayments] = useState([]);
  const [paymentAmount, setPaymentAmount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState("CRYPTO_ETH");
  const [paying, setPaying] = useState(false);
  const [payError, setPayError] = useState(null);

  useEffect(() => {
    if (user && params?.id) {
      loadLoan();
    }
  }, [user, params]);

  const loadLoan = () => {
    const l = dbService.getLoanById(params.id, user);
    if (l) {
      setLoan(l);
      setPaymentAmount(l.monthly_installment || 500);
      setRepayments(dbService.getRepayments(user, l.id));
    }
  };

  const handleMakePayment = async (e) => {
    e.preventDefault();
    setPayError(null);
    setPaying(true);

    try {
      let txHash = null;

      // If Crypto, attempt Sepolia payment via MetaMask
      if (paymentMethod === "CRYPTO_ETH") {
        try {
          const ethAmount = paymentAmount / 3000; // approximate ETH equivalence
          txHash = await contractService.makeRepaymentOnChain(
            loan.blockchain_loan_id || 1,
            ethAmount.toFixed(4)
          );
        } catch (chainErr) {
          console.warn("On-chain settlement bypass note:", chainErr.message);
        }
      }

      dbService.makeRepayment(
        loan.id,
        user,
        Number(paymentAmount),
        paymentMethod,
        txHash,
        `Payment installment via ${paymentMethod}`
      );

      loadLoan();
    } catch (err) {
      setPayError(err.message || "Payment execution failed.");
    } finally {
      setPaying(false);
    }
  };

  if (!loan) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center text-slate-500 text-xs">
        Loan record not found or unauthorized access.
      </div>
    );
  }

  const progressPercent = Math.min(
    100,
    Math.round(((loan.total_repayable - loan.remaining_balance) / loan.total_repayable) * 100)
  );

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-8">
      <button
        onClick={() => navigate("/dashboard")}
        className="flex items-center gap-2 text-xs text-slate-400 hover:text-white transition-colors"
      >
        <ArrowLeft className="w-3.5 h-3.5" /> Back to Dashboard
      </button>

      {/* Overview Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-white font-mono">{loan.loan_number}</h1>
              <StatusBadge status={loan.status} />
            </div>
            <p className="text-xs text-slate-400">
              Serviced loan for {loan.borrower?.full_name || "Borrower"}
            </p>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-400">Remaining Balance</span>
            <div className="text-2xl font-bold text-blue-400 font-mono">
              ${loan.remaining_balance.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Repayment Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-slate-400">
            <span>Repayment Progress</span>
            <span className="font-mono text-emerald-400 font-bold">{progressPercent}% Settled</span>
          </div>
          <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
            <div
              className="h-full bg-gradient-to-r from-blue-500 to-emerald-500 transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <div className="flex justify-between text-[11px] text-slate-500 font-mono">
            <span>$0</span>
            <span>Total: ${loan.total_repayable.toLocaleString()}</span>
          </div>
        </div>

        {/* Loan Details Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs">
          <div>
            <span className="text-slate-500">Principal Amount</span>
            <div className="font-mono font-bold text-slate-200">${loan.principal_amount.toLocaleString()}</div>
          </div>
          <div>
            <span className="text-slate-500">Interest APR</span>
            <div className="font-mono font-bold text-slate-200">{loan.interest_rate}%</div>
          </div>
          <div>
            <span className="text-slate-500">Term Duration</span>
            <div className="font-mono font-bold text-slate-200">{loan.term_months} Months</div>
          </div>
          <div>
            <span className="text-slate-500">Monthly Installment</span>
            <div className="font-mono font-bold text-blue-400">${loan.monthly_installment.toLocaleString()}</div>
          </div>
        </div>
      </div>

      {/* Repay Form & Settlement History */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Payment Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-emerald-400" />
            Make Installment Payment
          </h2>

          {loan.remaining_balance <= 0 ? (
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs text-center font-bold">
              🎉 This loan is 100% completed and fully repaid!
            </div>
          ) : (
            <form onSubmit={handleMakePayment} className="space-y-4">
              {payError && (
                <div className="p-2 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[11px]">
                  {payError}
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs text-slate-400">Payment Amount ($)</label>
                <input
                  type="number"
                  required
                  min="1"
                  max={loan.remaining_balance}
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-400">Payment Rail</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200"
                >
                  <option value="CRYPTO_ETH">Web3 MetaMask (Sepolia ETH)</option>
                  <option value="ESCROW_CLEARING">Direct Escrow Bank Transfer</option>
                </select>
              </div>

              <button
                type="submit"
                disabled={paying}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-all shadow-md shadow-emerald-500/20 cursor-pointer disabled:opacity-50"
              >
                {paying ? "Processing Settlement..." : `Submit Payment ($${paymentAmount})`}
              </button>
            </form>
          )}
        </div>

        {/* History */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-blue-400" />
            Repayment Ledger ({repayments.length} Payments)
          </h2>

          {repayments.length === 0 ? (
            <div className="p-12 text-center text-slate-500 text-xs">
              No payments made on this loan yet.
            </div>
          ) : (
            <div className="divide-y divide-slate-800">
              {repayments.map((rep) => (
                <div key={rep.id} className="py-3 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-white">Installment #{rep.installment_number}</span>
                    <p className="text-[11px] text-slate-400">
                      {new Date(rep.payment_date).toLocaleString()} via {rep.payment_method}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold text-emerald-400">${rep.amount.toLocaleString()}</span>
                    {rep.on_chain_tx_hash && (
                      <p className="text-[10px] text-blue-400 font-mono">
                        Tx: {rep.on_chain_tx_hash.slice(0, 10)}...
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoanDetailsPage;
