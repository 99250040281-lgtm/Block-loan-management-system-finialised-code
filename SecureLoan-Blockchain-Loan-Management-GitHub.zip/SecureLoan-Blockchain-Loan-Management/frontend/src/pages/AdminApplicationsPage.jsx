import React, { useState, useEffect } from "react";
import {
  FileCheck2,
  CheckCircle2,
  XCircle,
  UserCheck,
  ShieldCheck,
  Coins,
  ExternalLink,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import dbService from "../services/dbService";
import contractService from "../services/contractService";
import StatusBadge from "../components/StatusBadge";

export const AdminApplicationsPage = () => {
  const { user } = useAuth();
  const [applications, setApplications] = useState([]);
  const [selectedApp, setSelectedApp] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [remarks, setRemarks] = useState("");
  const [approvalRate, setApprovalRate] = useState(8.5);

  useEffect(() => {
    if (user) {
      loadApps();
      return dbService.subscribeToApplicationUpdates(loadApps);
    }
  }, [user]);

  const loadApps = () => {
    setApplications(dbService.getApplications(user));
  };

  const handleAssign = (appId) => {
    try {
      dbService.assignAdmin(appId, user.id, user);
      loadApps();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleApprove = async (app) => {
    setActionLoading(true);
    try {
      let txHash = null;
      let onChainLoanId = null;

      // Execute on-chain smart contract approval & funding if configured
      try {
        const dummyIpfs = "QmZtmD2qtQgX2qM2BqS5eXZn9T8L4DkE3qX9F2a1b0c9d8";
        // Approve on chain
        txHash = await contractService.approveLoanOnChain(
          app.blockchain_loan_id || 1,
          remarks || "Approved by Administrator Mahesh"
        );
      } catch (chainErr) {
        console.warn("On-chain execution note:", chainErr.message);
      }

      dbService.approveApplication(app.id, user, {
        remarks: remarks || "Approved after review",
        interest_rate: approvalRate,
        onChainTxHash: txHash,
        blockchainLoanId: onChainLoanId,
      });

      setSelectedApp(null);
      setRemarks("");
      loadApps();
    } catch (err) {
      alert(err.message || "Approval failed.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async (app) => {
    if (!remarks) {
      alert("Please provide rejection reason remarks.");
      return;
    }
    setActionLoading(true);
    try {
      let txHash = null;
      try {
        txHash = await contractService.rejectLoanOnChain(app.blockchain_loan_id || 1, remarks);
      } catch (chainErr) {
        console.warn("On-chain rejection note:", chainErr.message);
      }

      dbService.rejectApplication(app.id, user, remarks, txHash);
      setSelectedApp(null);
      setRemarks("");
      loadApps();
    } catch (err) {
      alert(err.message || "Rejection failed.");
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Loan Application Underwriting Queue</h1>
        <p className="text-xs text-slate-400">
          Review borrower submissions, verify credentials, assign administrative ownership, and approve on-chain disbursement.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Applications List */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          {applications.length === 0 ? (
            <div className="p-16 text-center text-slate-500 text-xs">
              No applications submitted yet.
            </div>
          ) : (
            <div className="divide-y divide-slate-800">
              {applications.map((app) => (
                <div
                  key={app.id}
                  onClick={() => setSelectedApp(app)}
                  className={`p-5 flex items-center justify-between cursor-pointer transition-colors ${
                    selectedApp?.id === app.id ? "bg-slate-800/80" : "hover:bg-slate-800/40"
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white font-mono">{app.application_number}</span>
                      <StatusBadge status={app.status} />
                    </div>
                    <p className="text-xs text-slate-300">
                      Applicant: {app.borrower?.full_name || "Borrower"} ({app.borrower?.email})
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Purpose: {app.purpose} | Income: ${app.annual_income?.toLocaleString()}/yr
                    </p>
                  </div>

                  <div className="text-right">
                    <div className="font-mono font-bold text-white text-base">
                      ${app.amount?.toLocaleString()}
                    </div>
                    <span className="text-[11px] text-slate-500">{app.term_months} Months</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Underwriting Actions Panel */}
        <div>
          {selectedApp ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <FileCheck2 className="w-4 h-4 text-blue-400" />
                Underwriting: {selectedApp.application_number}
              </h2>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Borrower:</span>
                  <span className="text-slate-200">{selectedApp.borrower?.full_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Requested Amount:</span>
                  <span className="text-blue-400 font-bold font-mono">
                    ${selectedApp.amount?.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Credit Score:</span>
                  <span className="text-emerald-400 font-bold font-mono">{selectedApp.credit_score}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Assigned Admin:</span>
                  <span className="text-slate-200">
                    {selectedApp.assigned_admin?.full_name || (
                      <span className="text-amber-400">Unassigned</span>
                    )}
                  </span>
                </div>
              </div>

              {!selectedApp.admin_id && (
                <button
                  onClick={() => handleAssign(selectedApp.id)}
                  className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold cursor-pointer"
                >
                  Assign to Me (Mahesh)
                </button>
              )}

              {selectedApp.status === "PENDING" || selectedApp.status === "UNDER_REVIEW" ? (
                <div className="space-y-4 pt-2">
                  <div className="space-y-1">
                    <label className="text-xs text-slate-400">Approved Interest APR (%)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={approvalRate}
                      onChange={(e) => setApprovalRate(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs text-slate-400">Administrator Remarks</label>
                    <textarea
                      rows="2"
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      placeholder="e.g. Credit verified, collateral satisfactory."
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => handleApprove(selectedApp)}
                      disabled={actionLoading}
                      className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20 cursor-pointer disabled:opacity-50"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" /> Approve Loan
                    </button>
                    <button
                      onClick={() => handleReject(selectedApp)}
                      disabled={actionLoading}
                      className="py-2.5 rounded-xl bg-rose-600/80 hover:bg-rose-600 text-white font-semibold text-xs flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      <XCircle className="w-3.5 h-3.5" /> Reject
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-3 rounded-xl bg-slate-950 text-center text-xs text-slate-400">
                  This application status is <span className="font-bold text-white">{selectedApp.status}</span>.
                </div>
              )}
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-500 text-xs">
              Select an application on the left to review documentation and execute approval decisions.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminApplicationsPage;
