import React, { useState, useEffect } from "react";
import { Coins, CheckCircle2, AlertCircle, ArrowRight } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import dbService from "../services/dbService";
import StatusBadge from "../components/StatusBadge";

export const AdminLoansPage = () => {
  const { user } = useAuth();
  const [loans, setLoans] = useState([]);

  useEffect(() => {
    if (user) {
      setLoans(dbService.getLoans(user));
    }
  }, [user]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Active Serviced Loan Portfolio</h1>
        <p className="text-xs text-slate-400">
          Supervise active credit facilities, track remaining principal balances, and monitor amortization schedules.
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        {loans.length === 0 ? (
          <div className="p-16 text-center text-slate-500 text-xs">
            No active loans servicing in institutional portfolio.
          </div>
        ) : (
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="p-4">Loan Number</th>
                <th className="p-4">Borrower</th>
                <th className="p-4">Principal</th>
                <th className="p-4">APR</th>
                <th className="p-4">Term</th>
                <th className="p-4">Remaining</th>
                <th className="p-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {loans.map((loan) => (
                <tr key={loan.id} className="hover:bg-slate-800/40">
                  <td className="p-4 font-mono font-bold text-white">{loan.loan_number}</td>
                  <td className="p-4 text-slate-300 font-medium">
                    {loan.borrower?.full_name || "Borrower"}
                  </td>
                  <td className="p-4 font-mono text-slate-300">${loan.principal_amount?.toLocaleString()}</td>
                  <td className="p-4 font-mono text-slate-300">{loan.interest_rate}%</td>
                  <td className="p-4 text-slate-400">{loan.term_months} mos</td>
                  <td className="p-4 font-mono font-bold text-blue-400">${loan.remaining_balance?.toLocaleString()}</td>
                  <td className="p-4">
                    <StatusBadge status={loan.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default AdminLoansPage;
