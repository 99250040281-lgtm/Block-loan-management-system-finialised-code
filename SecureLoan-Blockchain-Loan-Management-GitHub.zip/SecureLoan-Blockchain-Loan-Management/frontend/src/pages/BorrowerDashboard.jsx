import React, { useState, useEffect } from "react";
import {
  FilePlus,
  ArrowRight,
  Coins,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  DollarSign,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useNavigation } from "../context/NavigationContext";
import dbService from "../services/dbService";
import StatusBadge from "../components/StatusBadge";
import ContractStateWidget from "../components/ContractStateWidget";

export const BorrowerDashboard = () => {
  const { user } = useAuth();
  const { navigate } = useNavigation();

  const [metrics, setMetrics] = useState({
    totalApplications: 0,
    activeLoansCount: 0,
    totalOutstanding: 0,
    totalRepaid: 0,
    nextRepaymentAmount: 0,
    nextDueDate: null,
  });
  const [activeLoans, setActiveLoans] = useState([]);
  const [recentApplications, setRecentApplications] = useState([]);

  useEffect(() => {
    if (user) {
      loadData();
      const unsub = dbService.subscribeToApplicationUpdates(() => {
        loadData();
      });
      return unsub;
    }
  }, [user]);

  const loadData = () => {
    const m = dbService.getBorrowerMetrics(user);
    setMetrics(m);
    const loans = dbService.getLoans(user).filter((l) => l.status === "ACTIVE");
    setActiveLoans(loans);
    const apps = dbService.getApplications(user);
    setRecentApplications(apps.slice(0, 5));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header with Quick Apply */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Borrower Portal
          </h1>
          <p className="text-xs text-slate-400">
            Welcome back, {user?.full_name || "Borrower"}. Manage loans and track smart contract events.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate("/apply-loan")}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-all shadow-md shadow-blue-500/20 cursor-pointer"
          >
            <FilePlus className="w-4 h-4" />
            Apply For Loan
          </button>
          <button
            onClick={() => navigate("/my-loans")}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs transition-colors cursor-pointer"
          >
            View All Applications
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <span className="text-xs font-medium text-slate-400">Active Serviced Loans</span>
          <div className="text-2xl font-bold text-white">{metrics.activeLoansCount}</div>
          <p className="text-[11px] text-slate-500">{metrics.totalApplications} total submitted</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <span className="text-xs font-medium text-slate-400">Total Outstanding Balance</span>
          <div className="text-2xl font-bold text-blue-400 font-mono">
            ${metrics.totalOutstanding.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500">Principal + interest amortized</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <span className="text-xs font-medium text-slate-400">Total Settled Repayments</span>
          <div className="text-2xl font-bold text-emerald-400 font-mono">
            ${metrics.totalRepaid.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500">Cleared via on-chain / escrow</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <span className="text-xs font-medium text-slate-400">Next Due Installment</span>
          <div className="text-2xl font-bold text-amber-400 font-mono">
            ${metrics.nextRepaymentAmount.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500">
            {metrics.nextDueDate ? `Due date: ${metrics.nextDueDate}` : "No scheduled dues"}
          </p>
        </div>
      </div>

      {/* Main Grid: Active Loans & Recent Applications */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Loans and Applications */}
        <div className="lg:col-span-2 space-y-8">
          {/* Active Loans */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Coins className="w-5 h-5 text-blue-400" />
                Active Serviced Loans ({activeLoans.length})
              </h2>
              {activeLoans.length > 0 && (
                <button
                  onClick={() => navigate("/repayments")}
                  className="text-xs text-blue-400 hover:text-blue-300 font-semibold"
                >
                  Make Payment →
                </button>
              )}
            </div>

            {activeLoans.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                No active loans currently servicing. Apply for a loan to get started.
              </div>
            ) : (
              <div className="space-y-4">
                {activeLoans.map((loan) => (
                  <div
                    key={loan.id}
                    className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-white font-mono">{loan.loan_number}</span>
                        <StatusBadge status={loan.status} />
                      </div>
                      <p className="text-xs text-slate-400">
                        Principal: ${loan.principal_amount.toLocaleString()} | Rate: {loan.interest_rate}% | Term: {loan.term_months} mos
                      </p>
                      <p className="text-[11px] text-slate-500">
                        Remaining: <span className="text-blue-400 font-mono">${loan.remaining_balance.toLocaleString()}</span>
                      </p>
                    </div>

                    <button
                      onClick={() => navigate(`/loans/${loan.id}`)}
                      className="px-4 py-2 rounded-lg bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 border border-blue-500/20 text-xs font-semibold cursor-pointer"
                    >
                      Loan Details & Repay
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent Applications */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-indigo-400" />
              Recent Loan Applications
            </h2>

            {recentApplications.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                No applications found. Click "Apply For Loan" above.
              </div>
            ) : (
              <div className="divide-y divide-slate-800">
                {recentApplications.map((app) => (
                  <div key={app.id} className="py-3 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-semibold text-white font-mono">{app.application_number}</div>
                      <div className="text-slate-400">{app.purpose}</div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-slate-200">${app.amount.toLocaleString()}</span>
                      <StatusBadge status={app.status} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Col: Smart Contract Info */}
        <div className="space-y-6">
          <ContractStateWidget />
        </div>
      </div>
    </div>
  );
};

export default BorrowerDashboard;
