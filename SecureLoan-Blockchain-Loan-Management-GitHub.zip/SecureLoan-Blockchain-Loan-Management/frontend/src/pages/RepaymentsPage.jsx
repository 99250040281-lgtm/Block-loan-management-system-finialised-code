import React, { useState, useEffect } from "react";
import { Coins, Calendar, CheckCircle2, FileText, ArrowRight } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useNavigation } from "../context/NavigationContext";
import dbService from "../services/dbService";

export const RepaymentsPage = () => {
  const { user } = useAuth();
  const { navigate } = useNavigation();

  const [repayments, setRepayments] = useState([]);
  const [loans, setLoans] = useState([]);

  useEffect(() => {
    if (user) {
      setRepayments(dbService.getRepayments(user));
      setLoans(dbService.getLoans(user).filter((l) => l.status === "ACTIVE"));
    }
  }, [user]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Repayments Ledger</h1>
        <p className="text-xs text-slate-400">
          Track all historical payments, installment allocations, and payment receipts.
        </p>
      </div>

      {loans.length > 0 && (
        <div className="p-4 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-between">
          <div className="text-xs text-blue-300">
            You have <span className="font-bold">{loans.length} active serviced loan(s)</span> awaiting settlement.
          </div>
          <button
            onClick={() => navigate(`/loans/${loans[0].id}`)}
            className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-colors"
          >
            Pay Active Loan →
          </button>
        </div>
      )}

      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        {repayments.length === 0 ? (
          <div className="p-16 text-center text-slate-500 text-xs">
            No repayment transactions recorded yet.
          </div>
        ) : (
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="p-4">Installment</th>
                <th className="p-4">Date & Time</th>
                <th className="p-4">Method</th>
                <th className="p-4">Principal</th>
                <th className="p-4">Interest</th>
                <th className="p-4">Total Amount</th>
                <th className="p-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {repayments.map((rep) => (
                <tr key={rep.id} className="hover:bg-slate-800/40">
                  <td className="p-4 font-mono font-bold text-white">#{rep.installment_number}</td>
                  <td className="p-4 text-slate-400">{new Date(rep.payment_date).toLocaleDateString()}</td>
                  <td className="p-4 text-slate-300 font-mono text-[11px]">{rep.payment_method}</td>
                  <td className="p-4 font-mono text-slate-300">${rep.principal_paid?.toLocaleString()}</td>
                  <td className="p-4 font-mono text-slate-300">${rep.interest_paid?.toLocaleString()}</td>
                  <td className="p-4 font-mono font-bold text-emerald-400">${rep.amount.toLocaleString()}</td>
                  <td className="p-4">
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" /> PAID
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default RepaymentsPage;
