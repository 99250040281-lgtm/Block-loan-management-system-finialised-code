import React, { useState, useEffect } from "react";
import { ShieldCheck, ExternalLink, ArrowUpRight, ArrowDownLeft } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import dbService from "../services/dbService";
import contractService from "../services/contractService";

export const TransactionsPage = () => {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const config = contractService.getConfig();

  useEffect(() => {
    if (user) {
      setTransactions(dbService.getTransactions(user));
    }
  }, [user]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Audit Trail & Blockchain Transactions</h1>
        <p className="text-xs text-slate-400">
          Cryptographically signed records for loan disbursements, repayments, and escrow state updates.
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        {transactions.length === 0 ? (
          <div className="p-16 text-center text-slate-500 text-xs">
            No transactions found in audit ledger.
          </div>
        ) : (
          <div className="divide-y divide-slate-800">
            {transactions.map((tx) => (
              <div key={tx.id} className="p-4 flex items-center justify-between text-xs hover:bg-slate-800/40">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                      tx.type === "DISBURSEMENT"
                        ? "bg-purple-500/10 text-purple-400 border border-purple-500/20"
                        : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                    }`}
                  >
                    {tx.type === "DISBURSEMENT" ? (
                      <ArrowUpRight className="w-5 h-5" />
                    ) : (
                      <ArrowDownLeft className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <div className="font-bold text-white flex items-center gap-2">
                      <span>{tx.type}</span>
                      <span className="text-[10px] text-slate-500 font-mono">({tx.network})</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {new Date(tx.created_at).toLocaleString()} | Beneficiary: {tx.borrower_name}
                    </p>
                    {tx.tx_hash && (
                      <a
                        href={`${config.blockExplorerUrl}/tx/${tx.tx_hash}`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[10px] text-blue-400 font-mono flex items-center gap-1 hover:underline"
                      >
                        Tx: {tx.tx_hash.slice(0, 14)}...{tx.tx_hash.slice(-8)}
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    )}
                  </div>
                </div>

                <div className="text-right">
                  <div
                    className={`font-mono font-bold text-sm ${
                      tx.type === "DISBURSEMENT" ? "text-purple-400" : "text-emerald-400"
                    }`}
                  >
                    {tx.type === "DISBURSEMENT" ? "+" : "-"}${tx.amount.toLocaleString()}
                  </div>
                  <span className="text-[10px] text-emerald-400 font-semibold">{tx.status}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default TransactionsPage;
