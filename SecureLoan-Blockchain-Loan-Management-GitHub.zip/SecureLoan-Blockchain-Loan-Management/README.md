# Blockchain-Based Secure Loan Management System

An academic project prototype for managing loan applications with a React frontend, Node.js/Express API, PostgreSQL schema, and an Ethereum Solidity smart contract.

## Project structure

- `frontend/` — React + Vite user interface
- `backend/` — Express API, controllers, routes, middleware, and PostgreSQL models
- `blockchain/` — Solidity contract, Hardhat configuration, deployment script, and tests
- `database/` — SQL schema, migration, and sample data
- `wallet-integration/` — wallet connection and contract client helpers
- `configuration/` — safe configuration template and public network metadata
- `deployment/` — Docker and Cloud Run deployment configuration
- `tests/` — project test files

## Prerequisites

- Node.js 18 or newer and npm
- PostgreSQL for backend database features
- A browser wallet and Sepolia test ETH for blockchain transactions

## Setup

1. Copy `configuration/.env.example` to `configuration/.env`.
2. Fill in local values in `configuration/.env`. Never commit `.env`, passwords, API keys, JWT secrets, or wallet private keys.
3. Install and run the frontend:

   ```bash
   cd frontend
   npm install
   npm run dev
   ```

4. In a separate terminal, install and run the backend:

   ```bash
   cd backend
   npm install
   npm run dev
   ```

5. For the smart contract tests:

   ```bash
   cd blockchain
   npm install
   npm test
   ```

   Compile with `npm run compile`.

Refer to the source configuration and deployment files before attempting deployment. Do not deploy to a live network or use real funds until the contract and application have been independently reviewed.

## Important implementation and security status

This repository is an academic prototype and is **not production-ready**. The current source review found issues that must be addressed before public or real-user use:

- The frontend authentication service stores borrower passwords in browser `localStorage` and performs an admin login without validating the supplied password.
- The backend login controller issues an admin JWT based on the configured admin email without validating the password. The borrower registration/login flow also needs password storage and verification to be implemented securely.
- Several frontend application records are stored in browser `localStorage`; this is not equivalent to persistent PostgreSQL-backed application data.
- Role checks in the API and smart contract need end-to-end testing and a security review.
- The project presentation/report should describe only the roles, contracts, database behavior, and test results that the code actually implements.

Do not use this prototype to process real loan applications, identity documents, payments, or private financial information. Before production use, implement server-side password hashing and verification, secure session/token handling, server-enforced authorization, persistent database-backed application flows, and an independent smart-contract security review.

## Tests

Test scripts are included under the frontend, backend, and blockchain folders. Install each folder's dependencies before running them. Test execution and successful builds have not yet been verified for this packaged copy.

## License

MIT (confirm the intended project license with all team members before publishing).
