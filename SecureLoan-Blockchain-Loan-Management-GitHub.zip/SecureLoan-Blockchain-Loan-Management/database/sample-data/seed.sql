-- Seed Data for Blockchain-Based Secure Loan Management System

INSERT INTO profiles (id, email, full_name, role, phone, wallet_address, organization)
VALUES
('usr_admin_mahesh', 'kurubamahesh.cse@gmail.com', 'Mahesh', 'admin', '+919876543210', '0x0A97E36CBE94132F2ffFe08dBEa72b3F3f90F7b0', 'Institutional Administration Unit'),
('usr_borrower_alex', 'alex.borrower@example.com', 'Alex Mercer', 'borrower', '+15550198234', '0x70997970C51812dc3A010C7d01b50e0d17dc79C8', 'Tech Innovations LLC')
ON CONFLICT (id) DO NOTHING;

INSERT INTO applications (id, application_number, borrower_id, admin_id, amount, purpose, term_months, annual_income, employment_type, employer_name, credit_score, status, interest_rate_bps, approved_amount, remarks, conditions, blockchain_loan_id, on_chain_tx_hash)
VALUES
('app_1728000001', 'APP-2026-001', 'usr_borrower_alex', 'usr_admin_mahesh', 25000, 'Business Expansion & Working Capital', 24, 95000, 'Full-Time Employed', 'Tech Innovations LLC', 760, 'APPROVED', 850, 25000, 'Credit verified with positive institutional review.', 'Quarterly financial reporting required.', 1, '0x4a9b2c8e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1b0c9d8e7f6a5b4')
ON CONFLICT (id) DO NOTHING;

INSERT INTO loans (id, loan_number, application_id, borrower_id, principal_amount, interest_rate, total_repayable, remaining_balance, monthly_installment, term_months, start_date, due_date, status, blockchain_loan_id, on_chain_tx_hash)
VALUES
('loan_1728000001', 'LN-2026-001', 'app_1728000001', 'usr_borrower_alex', 25000, 8.5, 29250, 26812.5, 1218.75, 24, '2026-09-11', '2028-09-11', 'ACTIVE', 1, '0x4a9b2c8e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1b0c9d8e7f6a5b4')
ON CONFLICT (id) DO NOTHING;

INSERT INTO repayments (id, loan_id, borrower_id, installment_number, amount, principal_paid, interest_paid, payment_method, status, payment_date, on_chain_tx_hash, receipt_url, notes)
VALUES
('rep_1728000001', 'loan_1728000001', 'usr_borrower_alex', 1, 2437.5, 2246.54, 190.96, 'CRYPTO_ETH', 'PAID', NOW(), '0x8e7f6a5b4c3d2e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1b0c9d8e7', '/receipts/REC-001923.pdf', 'Installment #1 settled on-chain via Sepolia')
ON CONFLICT (id) DO NOTHING;

INSERT INTO transactions (id, loan_id, application_id, borrower_id, borrower_name, type, amount, status, tx_hash, network)
VALUES
('tx_1728000001', 'loan_1728000001', 'app_1728000001', 'usr_borrower_alex', 'Alex Mercer', 'DISBURSEMENT', 25000, 'COMPLETED', '0x4a9b2c8e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1b0c9d8e7f6a5b4', 'Ethereum Sepolia Testnet'),
('tx_1728000002', 'loan_1728000001', 'app_1728000001', 'usr_borrower_alex', 'Alex Mercer', 'REPAYMENT', 2437.5, 'COMPLETED', '0x8e7f6a5b4c3d2e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1b0c9d8e7', 'Ethereum Sepolia Testnet')
ON CONFLICT (id) DO NOTHING;
