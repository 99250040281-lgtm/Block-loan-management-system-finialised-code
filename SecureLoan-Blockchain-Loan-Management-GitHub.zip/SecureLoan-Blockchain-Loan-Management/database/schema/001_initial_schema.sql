-- =======================================================================
-- Blockchain-Based Secure Loan Management System - Database Schema (PostgreSQL/Supabase)
-- =======================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. PROFILES TABLE (Role-Based Access Control)
CREATE TABLE IF NOT EXISTS profiles (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('borrower', 'admin', 'super_admin')),
    phone TEXT DEFAULT '',
    wallet_address TEXT DEFAULT '',
    organization TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. LOAN APPLICATIONS TABLE
CREATE TABLE IF NOT EXISTS applications (
    id TEXT PRIMARY KEY,
    application_number TEXT UNIQUE NOT NULL,
    borrower_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    admin_id TEXT REFERENCES profiles(id) ON DELETE SET NULL,
    amount NUMERIC(15, 2) NOT NULL CHECK (amount > 0),
    purpose TEXT NOT NULL,
    term_months INTEGER NOT NULL CHECK (term_months >= 1 AND term_months <= 360),
    annual_income NUMERIC(15, 2) NOT NULL,
    employment_type TEXT NOT NULL,
    employer_name TEXT DEFAULT '',
    credit_score INTEGER DEFAULT 720,
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'UNDER_REVIEW', 'APPROVED', 'REJECTED', 'DISBURSED', 'ACTIVE', 'COMPLETED', 'DEFAULTED')),
    interest_rate_bps INTEGER DEFAULT 850, -- 8.5%
    approved_amount NUMERIC(15, 2),
    remarks TEXT DEFAULT '',
    conditions TEXT DEFAULT '',
    blockchain_loan_id INTEGER,
    on_chain_tx_hash TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. LOANS TABLE (Active & Serviced Loans)
CREATE TABLE IF NOT EXISTS loans (
    id TEXT PRIMARY KEY,
    loan_number TEXT UNIQUE NOT NULL,
    application_id TEXT NOT NULL REFERENCES applications(id) ON DELETE RESTRICT,
    borrower_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    principal_amount NUMERIC(15, 2) NOT NULL,
    interest_rate NUMERIC(5, 2) NOT NULL,
    total_repayable NUMERIC(15, 2) NOT NULL,
    remaining_balance NUMERIC(15, 2) NOT NULL,
    monthly_installment NUMERIC(15, 2) NOT NULL,
    term_months INTEGER NOT NULL,
    start_date DATE NOT NULL DEFAULT CURRENT_DATE,
    due_date DATE NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'COMPLETED', 'DEFAULTED', 'PAUSED')),
    blockchain_loan_id INTEGER,
    on_chain_tx_hash TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. REPAYMENTS TABLE
CREATE TABLE IF NOT EXISTS repayments (
    id TEXT PRIMARY KEY,
    loan_id TEXT NOT NULL REFERENCES loans(id) ON DELETE CASCADE,
    borrower_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    installment_number INTEGER NOT NULL,
    amount NUMERIC(15, 2) NOT NULL CHECK (amount > 0),
    principal_paid NUMERIC(15, 2) NOT NULL,
    interest_paid NUMERIC(15, 2) NOT NULL,
    payment_method TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'PAID' CHECK (status IN ('PENDING', 'PAID', 'FAILED')),
    payment_date TIMESTAMPTZ DEFAULT NOW(),
    on_chain_tx_hash TEXT,
    receipt_url TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. AUDIT & ESCROW TRANSACTIONS TABLE
CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    loan_id TEXT REFERENCES loans(id) ON DELETE SET NULL,
    application_id TEXT REFERENCES applications(id) ON DELETE SET NULL,
    borrower_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    borrower_name TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('DISBURSEMENT', 'REPAYMENT', 'FEE_ESCROW')),
    amount NUMERIC(15, 2) NOT NULL,
    status TEXT NOT NULL DEFAULT 'COMPLETED',
    tx_hash TEXT,
    network TEXT NOT NULL DEFAULT 'Ethereum Sepolia Testnet',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. LOAN DOCUMENTS TABLE
CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    application_id TEXT NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
    borrower_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    document_type TEXT NOT NULL,
    file_name TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    mime_type TEXT NOT NULL,
    file_url TEXT NOT NULL,
    ipfs_hash TEXT,
    verification_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (verification_status IN ('PENDING', 'VERIFIED', 'REJECTED')),
    verified_by TEXT REFERENCES profiles(id) ON DELETE SET NULL,
    verified_at TIMESTAMPTZ,
    remarks TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_apps_borrower ON applications(borrower_id);
CREATE INDEX IF NOT EXISTS idx_apps_admin ON applications(admin_id);
CREATE INDEX IF NOT EXISTS idx_loans_borrower ON loans(borrower_id);
CREATE INDEX IF NOT EXISTS idx_repayments_loan ON repayments(loan_id);
CREATE INDEX IF NOT EXISTS idx_txs_borrower ON transactions(borrower_id);
