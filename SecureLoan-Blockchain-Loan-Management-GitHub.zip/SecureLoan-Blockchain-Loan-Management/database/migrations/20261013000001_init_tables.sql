-- Migration: 20261013000001_init_tables
-- Applies initial schema structure with Row Level Security (RLS) policies

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE loans ENABLE ROW LEVEL SECURITY;
ALTER TABLE repayments ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;

-- Profile policies
CREATE POLICY "Public profiles are viewable by owner and admin"
ON profiles FOR SELECT USING (
    auth.uid()::text = id OR 
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Users can update own profile"
ON profiles FOR UPDATE USING (auth.uid()::text = id);

-- Application policies
CREATE POLICY "Borrowers see own applications, Admins see assigned or unassigned"
ON applications FOR SELECT USING (
    borrower_id = auth.uid()::text OR 
    admin_id = auth.uid()::text OR
    admin_id IS NULL AND EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Borrowers can insert applications"
ON applications FOR INSERT WITH CHECK (borrower_id = auth.uid()::text);

CREATE POLICY "Admins can update applications"
ON applications FOR UPDATE USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid()::text AND role = 'admin')
);
