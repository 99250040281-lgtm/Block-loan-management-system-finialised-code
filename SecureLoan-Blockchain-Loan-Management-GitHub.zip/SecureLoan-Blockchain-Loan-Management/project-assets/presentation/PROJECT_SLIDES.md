# Blockchain-Based Secure Loan Management System
## Academic & Project Presentation Deck

---

### Slide 1: Title Slide
- **Project Title**: Blockchain-Based Secure Loan Management System Using Smart Contracts
- **Lead Developer & System Architect**: Mahesh (`kurubamahesh.cse@gmail.com`)
- **Key Focus**: Decentralized lending, Role-Based Access Control (RBAC), Cryptographic Audit Trail, Smart Contract Disbursals.

---

### Slide 2: Problem Statement & Motivation
- **Traditional Lending Shortcomings**:
  - Centralized single point of failure and lack of borrower privacy.
  - Opaque loan underwriting decisions and susceptibility to unauthorized modifications.
  - Manual verification of collateral and income documents.
  - Lack of tamper-proof audit trail for interest calculations and installment settlement.

---

### Slide 3: Proposed Solution & System Architecture
- **Multi-Tiered Hybrid Architecture**:
  1. **Frontend**: React + Vite + Tailwind CSS + Lucide Icons + Ethers.js.
  2. **Blockchain Layer**: Ethereum Sepolia testnet running Solidity 0.8.20 Smart Contract (`LoanManagement.sol`).
  3. **Data Layer**: Reactive Local Database with BroadcastChannel real-time sync & PostgreSQL / Supabase hybrid persistence.
  4. **Wallet Integration**: MetaMask & EIP-6963 injected Web3 providers.

---

### Slide 4: Smart Contract Mechanics
- **Contract Name**: `LoanManagement.sol`
- **Role Hierarchy**:
  - `owner` / `admins`: Authorized underwriters capable of reviewing, approving, rejecting, and funding credit.
  - `borrower`: Submits loan requests with document IPFS hashes; executes repayments.
- **Key Functions**:
  - `applyLoan(amount, termMonths, interestRateBps, documentIpfsHash)`
  - `approveLoan(loanId, remarks)`
  - `fundLoan(loanId)` payable
  - `makeRepayment(loanId)` payable
  - `markRepaid(loanId)`

---

### Slide 5: Demonstration & Live Deployment
- **Cloud Run Live URL**: [https://blockchain-secure-loan-management-system-1066095006093.asia-southeast1.run.app](https://blockchain-secure-loan-management-system-1066095006093.asia-southeast1.run.app)
- **Target Testnet**: Ethereum Sepolia (Chain ID 11155111)
- **Verified Contract**: `0x35B19024c0C7d740E7A6930C664Eb894cAb7F648`

---

### Slide 6: Results, Impact & Future Scope
- **Results**: Complete elimination of unauthorized loan status tampering; automated balance decrement upon payment receipt; instant cryptographic receipt issuance.
- **Future Scope**:
  - Zero-Knowledge Proofs (zk-SNARKs) for anonymous credit scoring.
  - Decentralized Oracle network (Chainlink) for live collateral price feeds.
  - Multi-chain deployment on Polygon, Arbitrum, and Base.
