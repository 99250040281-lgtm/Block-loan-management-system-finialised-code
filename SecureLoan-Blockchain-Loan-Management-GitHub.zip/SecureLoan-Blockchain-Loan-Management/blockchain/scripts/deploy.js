const hre = require("hardhat");
const fs = require("fs");
const path = require("path");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("==================================================");
  console.log("Deploying LoanManagement contract with account:", deployer.address);
  
  const balance = await hre.ethers.provider.getBalance(deployer.address);
  console.log("Account balance:", hre.ethers.formatEther(balance), "ETH");
  console.log("Network:", hre.network.name);
  console.log("==================================================");

  const LoanManagement = await hre.ethers.getContractFactory("LoanManagement");
  const loanManagement = await LoanManagement.deploy();

  await loanManagement.waitForDeployment();
  const contractAddress = await loanManagement.getAddress();

  console.log("✅ LoanManagement deployed successfully to:", contractAddress);
  console.log("Contract Owner / SuperAdmin:", deployer.address);

  // Write deployment info
  const deploymentInfo = {
    network: hre.network.name,
    chainId: (await hre.ethers.provider.getNetwork()).chainId.toString(),
    contractAddress: contractAddress,
    deployerAddress: deployer.address,
    deployedAt: new Date().toISOString(),
    transactionHash: loanManagement.deploymentTransaction()?.hash || null,
  };

  const deploymentsDir = path.join(__dirname, "../deployments");
  if (!fs.existsSync(deploymentsDir)) {
    fs.mkdirSync(deploymentsDir, { recursive: true });
  }

  const deploymentPath = path.join(deploymentsDir, `${hre.network.name}.json`);
  fs.writeFileSync(deploymentPath, JSON.stringify(deploymentInfo, null, 2));
  console.log("📝 Saved deployment metadata to:", deploymentPath);

  // Also sync address to configuration
  const configEnvPath = path.join(__dirname, "../../configuration/.env");
  if (fs.existsSync(configEnvPath)) {
    let envContent = fs.readFileSync(configEnvPath, "utf8");
    if (envContent.includes("VITE_LOAN_CONTRACT_ADDRESS=")) {
      envContent = envContent.replace(
        /VITE_LOAN_CONTRACT_ADDRESS=.*/,
        `VITE_LOAN_CONTRACT_ADDRESS=${contractAddress}`
      );
      fs.writeFileSync(configEnvPath, envContent);
      console.log("🔄 Updated VITE_LOAN_CONTRACT_ADDRESS in configuration/.env");
    }
  }
}

main().catch((error) => {
  console.error("Deployment failed:", error);
  process.exitCode = 1;
});
