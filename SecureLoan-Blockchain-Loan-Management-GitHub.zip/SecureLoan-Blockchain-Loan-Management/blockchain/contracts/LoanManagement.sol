// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title LoanManagement
 * @dev Blockchain-Based Secure Loan Management System Using Smart Contracts
 */
contract LoanManagement {
    enum LoanStatus {
        PENDING,
        UNDER_REVIEW,
        APPROVED,
        REJECTED,
        DISBURSED,
        ACTIVE,
        COMPLETED,
        DEFAULTED
    }

    struct Loan {
        uint256 id;
        address borrower;
        uint256 principalAmount;
        uint256 termMonths;
        uint256 interestRateBps;
        uint256 totalRepayable;
        uint256 amountRepaid;
        LoanStatus status;
        string documentIpfsHash;
        string adminRemarks;
        uint256 createdAt;
        uint256 approvedAt;
        uint256 disbursedAt;
    }

    address public owner;
    mapping(address => bool) public admins;
    mapping(uint256 => Loan) public loans;
    uint256 public loanCounter;

    event LoanApplied(uint256 indexed loanId, address indexed borrower, uint256 amount, uint256 termMonths);
    event LoanStatusUpdated(uint256 indexed loanId, LoanStatus status, string remarks, address indexed updatedBy);
    event LoanDisbursed(uint256 indexed loanId, address indexed borrower, uint256 amount);
    event RepaymentMade(uint256 indexed loanId, address indexed payer, uint256 amount, uint256 remainingBalance);
    event LoanFullyRepaid(uint256 indexed loanId);

    modifier onlyAdmin() {
        require(admins[msg.sender] || msg.sender == owner, "Only authorized admin can call this");
        _;
    }

    modifier validLoan(uint256 loanId) {
        require(loanId > 0 && loanId <= loanCounter, "Invalid loan ID");
        _;
    }

    constructor() {
        owner = msg.sender;
        admins[msg.sender] = true;
    }

    function applyLoan(
        uint256 amount,
        uint256 termMonths,
        uint256 interestRateBps,
        string memory documentIpfsHash
    ) external returns (uint256) {
        require(amount > 0, "Loan amount must be greater than zero");
        require(termMonths > 0 && termMonths <= 360, "Term must be 1 to 360 months");

        loanCounter++;
        uint256 newLoanId = loanCounter;
        uint256 totalInterest = (amount * interestRateBps * termMonths) / (12 * 10000);
        uint256 totalRepayable = amount + totalInterest;

        loans[newLoanId] = Loan({
            id: newLoanId,
            borrower: msg.sender,
            principalAmount: amount,
            termMonths: termMonths,
            interestRateBps: interestRateBps,
            totalRepayable: totalRepayable,
            amountRepaid: 0,
            status: LoanStatus.PENDING,
            documentIpfsHash: documentIpfsHash,
            adminRemarks: "",
            createdAt: block.timestamp,
            approvedAt: 0,
            disbursedAt: 0
        });

        emit LoanApplied(newLoanId, msg.sender, amount, termMonths);
        return newLoanId;
    }

    function approveLoan(uint256 loanId, string memory remarks) external onlyAdmin validLoan(loanId) {
        Loan storage loan = loans[loanId];
        require(loan.status == LoanStatus.PENDING || loan.status == LoanStatus.UNDER_REVIEW, "Loan not pending review");
        loan.status = LoanStatus.APPROVED;
        loan.adminRemarks = remarks;
        loan.approvedAt = block.timestamp;
        emit LoanStatusUpdated(loanId, LoanStatus.APPROVED, remarks, msg.sender);
    }

    function rejectLoan(uint256 loanId, string memory remarks) external onlyAdmin validLoan(loanId) {
        Loan storage loan = loans[loanId];
        loan.status = LoanStatus.REJECTED;
        loan.adminRemarks = remarks;
        emit LoanStatusUpdated(loanId, LoanStatus.REJECTED, remarks, msg.sender);
    }

    function fundLoan(uint256 loanId) external payable onlyAdmin validLoan(loanId) {
        Loan storage loan = loans[loanId];
        require(loan.status == LoanStatus.APPROVED, "Loan must be approved before disbursement");
        require(msg.value == loan.principalAmount, "Sent amount does not match principal");
        loan.status = LoanStatus.DISBURSED;
        loan.disbursedAt = block.timestamp;
        (bool sent, ) = loan.borrower.call{value: msg.value}("");
        require(sent, "Disbursement transfer failed");
        emit LoanDisbursed(loanId, loan.borrower, msg.value);
        emit LoanStatusUpdated(loanId, LoanStatus.ACTIVE, "Disbursed and active", msg.sender);
        loan.status = LoanStatus.ACTIVE;
    }

    function makeRepayment(uint256 loanId) external payable validLoan(loanId) {
        Loan storage loan = loans[loanId];
        require(loan.status == LoanStatus.ACTIVE, "Loan is not currently active");
        require(msg.value > 0, "Repayment amount must be > 0");
        uint256 remaining = loan.totalRepayable - loan.amountRepaid;
        require(msg.value <= remaining, "Payment exceeds remaining balance");

        loan.amountRepaid += msg.value;
        uint256 newRemaining = loan.totalRepayable - loan.amountRepaid;
        emit RepaymentMade(loanId, msg.sender, msg.value, newRemaining);

        if (newRemaining == 0) {
            loan.status = LoanStatus.COMPLETED;
            emit LoanFullyRepaid(loanId);
        }
    }

    function markRepaid(uint256 loanId) external onlyAdmin validLoan(loanId) {
        Loan storage loan = loans[loanId];
        require(loan.status == LoanStatus.ACTIVE, "Loan is not active");
        loan.amountRepaid = loan.totalRepayable;
        loan.status = LoanStatus.COMPLETED;
        emit LoanFullyRepaid(loanId);
    }

    function getLoan(uint256 loanId) external view validLoan(loanId) returns (
        uint256 id, address borrower, uint256 principalAmount, uint256 termMonths,
        uint256 interestRateBps, uint256 totalRepayable, uint256 amountRepaid,
        LoanStatus status, string memory documentIpfsHash, string memory adminRemarks, uint256 createdAt
    ) {
        Loan memory l = loans[loanId];
        return (l.id, l.borrower, l.principalAmount, l.termMonths, l.interestRateBps, l.totalRepayable, l.amountRepaid, l.status, l.documentIpfsHash, l.adminRemarks, l.createdAt);
    }
}