const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("LoanManagement Smart Contract Test Suite", function () {
  let LoanManagement;
  let loanManagement;
  let owner;
  let admin;
  let borrower;
  let unauthorizedUser;

  const LOAN_AMOUNT = ethers.parseEther("1.0"); // 1 ETH
  const TERM_MONTHS = 12;
  const INTEREST_RATE_BPS = 850; // 8.5%
  const DOC_IPFS_HASH = "QmXoypizjW3WknFiJnKLwHCnL72vedxjQkDDP1mXWo6uco";

  beforeEach(async function () {
    [owner, admin, borrower, unauthorizedUser] = await ethers.getSigners();

    LoanManagement = await ethers.getContractFactory("LoanManagement");
    loanManagement = await LoanManagement.deploy();
    await loanManagement.waitForDeployment();

    // Set admin
    await loanManagement.setAdmin(admin.address, true);
  });

  describe("Deployment & Access Control", function () {
    it("should set deployer as owner and initial admin", async function () {
      expect(await loanManagement.owner()).to.equal(owner.address);
      expect(await loanManagement.admins(owner.address)).to.be.true;
    });

    it("should allow owner to assign and revoke admin rights", async function () {
      expect(await loanManagement.admins(admin.address)).to.be.true;
      await loanManagement.setAdmin(admin.address, false);
      expect(await loanManagement.admins(admin.address)).to.be.false;
    });

    it("should reject non-admin from updating status", async function () {
      // Borrower applies
      await loanManagement.connect(borrower).applyLoan(
        LOAN_AMOUNT,
        TERM_MONTHS,
        INTEREST_RATE_BPS,
        DOC_IPFS_HASH
      );

      await expect(
        loanManagement.connect(unauthorizedUser).approveLoan(1, "Self approval")
      ).to.be.revertedWith("Only authorized admin can call this");
    });
  });

  describe("Loan Lifecycle: Application to Repayment", function () {
    it("should allow borrower to submit a loan application", async function () {
      const tx = await loanManagement.connect(borrower).applyLoan(
        LOAN_AMOUNT,
        TERM_MONTHS,
        INTEREST_RATE_BPS,
        DOC_IPFS_HASH
      );

      await expect(tx)
        .to.emit(loanManagement, "LoanApplied")
        .withArgs(1, borrower.address, LOAN_AMOUNT, TERM_MONTHS);

      const loan = await loanManagement.getLoan(1);
      expect(loan.id).to.equal(1);
      expect(loan.borrower).to.equal(borrower.address);
      expect(loan.principalAmount).to.equal(LOAN_AMOUNT);
      expect(loan.termMonths).to.equal(TERM_MONTHS);
      expect(loan.interestRateBps).to.equal(INTEREST_RATE_BPS);
      expect(loan.status).to.equal(0); // PENDING
      expect(loan.documentIpfsHash).to.equal(DOC_IPFS_HASH);
    });

    it("should allow authorized admin to approve a loan", async function () {
      await loanManagement.connect(borrower).applyLoan(
        LOAN_AMOUNT,
        TERM_MONTHS,
        INTEREST_RATE_BPS,
        DOC_IPFS_HASH
      );

      await expect(
        loanManagement.connect(admin).approveLoan(1, "Approved by Mahesh")
      )
        .to.emit(loanManagement, "LoanStatusUpdated")
        .withArgs(1, 2, "Approved by Mahesh", admin.address); // 2 = APPROVED

      const loan = await loanManagement.getLoan(1);
      expect(loan.status).to.equal(2);
      expect(loan.adminRemarks).to.equal("Approved by Mahesh");
    });

    it("should allow admin to disburse funds to borrower", async function () {
      await loanManagement.connect(borrower).applyLoan(
        LOAN_AMOUNT,
        TERM_MONTHS,
        INTEREST_RATE_BPS,
        DOC_IPFS_HASH
      );
      await loanManagement.connect(admin).approveLoan(1, "Approved");

      const borrowerInitialBalance = await ethers.provider.getBalance(borrower.address);

      const disburseTx = await loanManagement.connect(admin).fundLoan(1, {
        value: LOAN_AMOUNT,
      });

      await expect(disburseTx)
        .to.emit(loanManagement, "LoanDisbursed")
        .withArgs(1, borrower.address, LOAN_AMOUNT);

      const borrowerFinalBalance = await ethers.provider.getBalance(borrower.address);
      expect(borrowerFinalBalance - borrowerInitialBalance).to.equal(LOAN_AMOUNT);

      const loan = await loanManagement.getLoan(1);
      expect(loan.status).to.equal(5); // ACTIVE
    });

    it("should accept repayments and complete loan when paid in full", async function () {
      await loanManagement.connect(borrower).applyLoan(
        LOAN_AMOUNT,
        TERM_MONTHS,
        INTEREST_RATE_BPS,
        DOC_IPFS_HASH
      );
      await loanManagement.connect(admin).approveLoan(1, "Approved");
      await loanManagement.connect(admin).fundLoan(1, { value: LOAN_AMOUNT });

      const loan = await loanManagement.getLoan(1);
      const totalRepayable = loan.totalRepayable;

      // Make partial payment
      const partialPayment = ethers.parseEther("0.5");
      await loanManagement.connect(borrower).makeRepayment(1, { value: partialPayment });

      const loanAfterPartial = await loanManagement.getLoan(1);
      expect(loanAfterPartial.amountRepaid).to.equal(partialPayment);

      // Settle remaining
      const remainingPayment = totalRepayable - partialPayment;
      const finalTx = await loanManagement.connect(borrower).makeRepayment(1, {
        value: remainingPayment,
      });

      await expect(finalTx)
        .to.emit(loanManagement, "LoanFullyRepaid")
        .withArgs(1);

      const loanFinal = await loanManagement.getLoan(1);
      expect(loanFinal.status).to.equal(6); // COMPLETED
      expect(loanFinal.amountRepaid).to.equal(totalRepayable);
    });
  });
});
