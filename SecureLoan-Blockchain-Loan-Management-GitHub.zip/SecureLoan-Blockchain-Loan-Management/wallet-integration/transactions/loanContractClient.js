import { ethers } from "ethers";
import LoanManagementABI from "./LoanManagementABI.json";

/**
 * LoanContractClient
 * High-level client for executing blockchain transactions on the LoanManagement contract.
 */
export class LoanContractClient {
  constructor(contractAddress = "", rpcUrl = "https://rpc.sepolia.org") {
    this.contractAddress = contractAddress;
    this.rpcUrl = rpcUrl;
    this.readOnlyProvider = new ethers.JsonRpcProvider(rpcUrl);
    this.contract = null;
  }

  setContractAddress(address) {
    this.contractAddress = address;
  }

  getReadOnlyContract() {
    if (!this.contractAddress) {
      throw new Error("Contract address is not configured.");
    }
    return new ethers.Contract(
      this.contractAddress,
      LoanManagementABI.abi,
      this.readOnlyProvider
    );
  }

  getSignedContract(signer) {
    if (!this.contractAddress) {
      throw new Error("Contract address is not configured.");
    }
    return new ethers.Contract(
      this.contractAddress,
      LoanManagementABI.abi,
      signer
    );
  }

  /**
   * Apply for loan on-chain
   * @param {ethers.Signer} signer
   * @param {string|number} amountEth
   * @param {number} termMonths
   * @param {number} interestRateBps
   * @param {string} ipfsHash
   */
  async applyLoan(signer, amountEth, termMonths, interestRateBps, ipfsHash) {
    const contract = this.getSignedContract(signer);
    const amountWei = ethers.parseEther(amountEth.toString());
    const tx = await contract.applyLoan(amountWei, termMonths, interestRateBps, ipfsHash);
    const receipt = await tx.wait();

    let loanId = null;
    for (const log of receipt.logs) {
      try {
        const parsed = contract.interface.parseLog(log);
        if (parsed && parsed.name === "LoanApplied") {
          loanId = Number(parsed.args[0]);
          break;
        }
      } catch {
        // ignore unparsed logs
      }
    }

    return { txHash: receipt.hash, loanId };
  }

  /**
   * Admin approve loan
   */
  async approveLoan(signer, loanId, remarks = "") {
    const contract = this.getSignedContract(signer);
    const tx = await contract.approveLoan(loanId, remarks);
    const receipt = await tx.wait();
    return { txHash: receipt.hash };
  }

  /**
   * Admin reject loan
   */
  async rejectLoan(signer, loanId, remarks = "") {
    const contract = this.getSignedContract(signer);
    const tx = await contract.rejectLoan(loanId, remarks);
    const receipt = await tx.wait();
    return { txHash: receipt.hash };
  }

  /**
   * Admin disburse / fund loan
   */
  async fundLoan(signer, loanId, amountEth) {
    const contract = this.getSignedContract(signer);
    const amountWei = ethers.parseEther(amountEth.toString());
    const tx = await contract.fundLoan(loanId, { value: amountWei });
    const receipt = await tx.wait();
    return { txHash: receipt.hash };
  }

  /**
   * Borrower loan repayment
   */
  async makeRepayment(signer, loanId, amountEth) {
    const contract = this.getSignedContract(signer);
    const amountWei = ethers.parseEther(amountEth.toString());
    const tx = await contract.makeRepayment(loanId, { value: amountWei });
    const receipt = await tx.wait();
    return { txHash: receipt.hash };
  }

  /**
   * Query loan details from chain
   */
  async getLoan(loanId) {
    const contract = this.getReadOnlyContract();
    const data = await contract.getLoan(loanId);
    return {
      id: Number(data[0]),
      borrower: data[1],
      principalAmount: ethers.formatEther(data[2]),
      termMonths: Number(data[3]),
      interestRateBps: Number(data[4]),
      totalRepayable: ethers.formatEther(data[5]),
      amountRepaid: ethers.formatEther(data[6]),
      status: Number(data[7]),
      documentIpfsHash: data[8],
      adminRemarks: data[9],
      createdAt: new Date(Number(data[10]) * 1000).toISOString(),
    };
  }
}

export default new LoanContractClient();
