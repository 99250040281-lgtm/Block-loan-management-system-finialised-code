import { ethers } from "ethers";

/**
 * WalletConnector
 * Manages Web3 wallet connections via window.ethereum and EIP-6963 provider announcements.
 * Handles accountsChanged, chainChanged events, and network switching to Sepolia testnet.
 */
export class WalletConnector {
  constructor() {
    this.provider = null;
    this.signer = null;
    this.accounts = [];
    this.chainId = null;
    this.listeners = new Set();
    this.initEIP6963();
  }

  static getInstance() {
    if (!WalletConnector.instance) {
      WalletConnector.instance = new WalletConnector();
    }
    return WalletConnector.instance;
  }

  initEIP6963() {
    if (typeof window !== "undefined") {
      window.addEventListener("eip6963:announceProvider", (event) => {
        // Discovered EIP-6963 wallet provider
        this.notifyListeners({ type: "PROVIDER_DISCOVERED", detail: event.detail });
      });
      window.dispatchEvent(new Event("eip6963:requestProvider"));

      if (window.ethereum) {
        window.ethereum.on("accountsChanged", (accounts) => {
          this.accounts = accounts;
          this.notifyListeners({ type: "ACCOUNTS_CHANGED", accounts });
        });

        window.ethereum.on("chainChanged", (chainIdHex) => {
          this.chainId = parseInt(chainIdHex, 16);
          this.notifyListeners({ type: "CHAIN_CHANGED", chainId: this.chainId });
        });

        window.ethereum.on("disconnect", () => {
          this.accounts = [];
          this.signer = null;
          this.notifyListeners({ type: "DISCONNECTED" });
        });
      }
    }
  }

  isMetaMaskAvailable() {
    return typeof window !== "undefined" && Boolean(window.ethereum);
  }

  async connectWallet() {
    if (!this.isMetaMaskAvailable()) {
      throw new Error("No Web3 wallet detected. Please install MetaMask to interact with the blockchain.");
    }

    this.provider = new ethers.BrowserProvider(window.ethereum);
    const accounts = await this.provider.send("eth_requestAccounts", []);
    if (!accounts || accounts.length === 0) {
      throw new Error("No accounts authorized in MetaMask.");
    }

    this.accounts = accounts;
    this.signer = await this.provider.getSigner();
    const network = await this.provider.getNetwork();
    this.chainId = Number(network.chainId);

    return {
      address: accounts[0],
      chainId: this.chainId,
      provider: this.provider,
      signer: this.signer,
    };
  }

  async getConnectedAddress() {
    if (!this.isMetaMaskAvailable()) return null;
    try {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const accounts = await provider.send("eth_accounts", []);
      return accounts.length > 0 ? accounts[0] : null;
    } catch {
      return null;
    }
  }

  async switchNetwork(targetChainIdHex = "0xaa36a7") {
    if (!this.isMetaMaskAvailable()) return;
    try {
      await window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: targetChainIdHex }],
      });
    } catch (switchError) {
      if (switchError.code === 4902) {
        await window.ethereum.request({
          method: "wallet_addEthereumChain",
          params: [
            {
              chainId: targetChainIdHex,
              chainName: "Sepolia Testnet",
              nativeCurrency: { name: "SepoliaETH", symbol: "ETH", decimals: 18 },
              rpcUrls: ["https://rpc.sepolia.org"],
              blockExplorerUrls: ["https://sepolia.etherscan.io"],
            },
          ],
        });
      } else {
        throw switchError;
      }
    }
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  notifyListeners(data) {
    this.listeners.forEach((listener) => {
      try {
        listener(data);
      } catch (err) {
        console.error("WalletConnector listener error:", err);
      }
    });
  }
}

export default WalletConnector.getInstance();
